import subprocess
import sys
import os
import time

def main():
    root_dir = os.path.dirname(os.path.abspath(__file__))
    backend_dir = os.path.join(root_dir, "backend")
    frontend_dir = os.path.join(root_dir, "frontend")

    print("=" * 80)
    print("STARTING AI COURSE RECOMMENDATION SYSTEM USING A* SEARCH")
    print("=" * 80)
    print("1. Backend Server:  http://localhost:8000 (API Docs at http://localhost:8000/docs)")
    print("2. Frontend Web UI: http://localhost:5173")
    print("=" * 80)

    # Environment with backend in PYTHONPATH
    env = os.environ.copy()
    env["PYTHONPATH"] = backend_dir

    # Start FastAPI Backend process
    backend_cmd = [sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"]
    print("\n[Backend] Launching FastAPI uvicorn server...")
    backend_proc = subprocess.Popen(backend_cmd, cwd=backend_dir, env=env)

    # Start React Frontend process
    frontend_cmd = ["npm.cmd" if sys.platform == "win32" else "npm", "run", "dev"]
    print("[Frontend] Launching React Vite dev server...")
    frontend_proc = subprocess.Popen(frontend_cmd, cwd=frontend_dir)

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping processes...")
        backend_proc.terminate()
        frontend_proc.terminate()
        print("Shutdown complete.")

if __name__ == "__main__":
    main()
