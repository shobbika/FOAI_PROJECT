# AI-Based Personalized Course Recommendation & Learning Path System Using A* Search

**Subject:** Artificial Intelligence & State-Space Search  
**Project Title:** AI-Based Personalized Course Recommendation and Learning Path System Using A* Search  
**Technology Stack:** Python, FastAPI, SQLite, React (Vite), Pure A* Search Engine from Scratch  

---

## 1. ABSTRACT
Modern online educational platforms present students with thousands of unorganized courses without offering structured, goal-directed guidance. Traditional recommender systems rely on popularity metrics or collaborative filtering, which fail to enforce strict prerequisite ordering or calculate shortest-path learning trajectories. This project presents an intelligent goal-oriented educational pathfinder that uses **A* State-Space Search** to recommend a personalized sequence of courses toward a selected career goal. By formulating states as sets of completed courses and acquired skills, the system enforces multi-prerequisite constraints, evaluates non-negative course costs ($g(n) = \text{duration} + \text{difficulty penalty}$), and applies a mathematically admissible heuristic ($h(n) = \max_{s \in M} \text{min\_cost}(s)$) to guarantee optimal, shortest-cost learning paths.

---

## 2. PROBLEM STATEMENT
Students seeking to transition into specialized tech careers (e.g., AI Engineer, Data Scientist) struggle with:
1. **Unstructured Curricula:** Inability to identify which foundational courses must precede advanced topics.
2. **Skill Redundancy:** Wasting time on courses teaching skills they already possess.
3. **Suboptimal Sequence:** Lack of intelligent path optimization considering study duration and course difficulty.
4. **Lack of Personalization:** Recommendation systems ignoring available weekly study hours and student skill gaps.

---

## 3. OBJECTIVES
- Implement a genuine **A* State-Space Search Algorithm from Scratch** in pure Python ($f(n) = g(n) + h(n)$).
- Model courses as a Directed Acyclic Graph (DAG) with complex multi-prerequisite dependencies.
- Formulate an **admissible heuristic function** $h(n)$ guaranteeing optimal (lowest-cost) path discovery.
- Convert A* optimal sequences into a **Personalized Weekly Study Timetable** respecting student daily study hour limits and available days.
- Validate dataset integrity (cycles, missing fields, duplicate IDs, invalid difficulty) at startup.
- Build a modular FastAPI backend with persistent SQLite student profile & study plan task tracking.
- Create an interactive React frontend dashboard featuring visual roadmaps, study planner timetables, task checkboxes, and search analytics.
- Benchmark A* Search against Uniform Cost Search (UCS / Dijkstra) to evaluate search space node reduction.

---

## 4. CORE AI PRINCIPLES & SEARCH ARCHITECTURE

| Core AI Concept | Implementation in Project |
| :--- | :--- |
| **Intelligent Agents** | Implements a goal-based problem-solving agent formulating goal states and action sequences. |
| **Problem-Solving Agents** | Formulates state spaces, transitions, cost evaluation, and goal test conditions. |
| **State-Space Search** | State $S = \text{FrozenSet}[ \text{Completed Course IDs} ]$. Acquired skills derived dynamically. |
| **Informed Search** | Uses evaluation function $f(S) = g(S) + h(S)$ to prioritize promising states. |
| **Heuristic Functions** | $h(S) = \max_{s \in \text{MissingSkills}} [ \text{min\_cost}(s) ]$, proven admissible ($h(S) \le h^*(S)$). |
| **A* Search Algorithm** | Implemented from scratch using priority queue (`heapq`), closed set, and tie-breaking. |
| **Timetable Scheduling** | Converts optimal A* path into day-by-day study tasks obeying prerequisite completion and daily capacity. |
| **Knowledge Representation** | JSON knowledge base modeling courses, prerequisites, career goals, and skills. |
| **Constraint Handling** | Enforces multi-prerequisite dependencies, non-negative costs, and cycle prevention. |

---

## 5. SYSTEM ARCHITECTURE

```mermaid
graph TD
    User([Student / Web Client]) -->|Profile, Goal & Study Availability| ReactUI[React + Vite Frontend Dashboard]
    ReactUI -->|REST API Requests| FastAPI[FastAPI Backend Server]
    
    subgraph Core Standalone AI & Planning Engine
        FastAPI -->|Invoke Recommendation| AStar[A* Search Recommender]
        FastAPI -->|Invoke Benchmark| UCS[Uniform Cost Search Engine]
        FastAPI -->|Invoke Timetable Generator| Planner[Study Planner Engine]
        AStar -->|Read Dataset Graph| Graph[Course Graph & Validator]
        AStar -->|Calculate g(n)| CostFunc[Cost Evaluator g(n)]
        AStar -->|Calculate h(n)| Heuristic[Admissible Heuristic h(n)]
        Planner -->|Request Optimal Course Sequence| AStar
        Planner -->|Modularize Course Duration into Tasks| Scheduler[Day & Hour Timetable Scheduler]
    end
    
    FastAPI -->|JSON / SQLite Query| DataLayer[(JSON Knowledge Base & SQLite DB)]
    AStar -->|Optimal Path & Search Metrics| FastAPI
    Planner -->|Personalized Weekly Timetable & Explanation| FastAPI
    FastAPI -->|JSON Response| ReactUI
```


---

## 6. A* ALGORITHM FORMULATION & MATHEMATICAL PROOF

### 6.1 State Representation
A state $S$ is defined as the set of completed course IDs:
$$S = \{ c_1, c_2, \dots, c_k \}$$
Acquired skills are dynamically derived from initial student skills plus skills taught by all completed courses:
$$\text{acquired\_skills}(S) = \text{initial\_skills} \cup \bigcup_{c \in S} \text{skills}(c)$$

### 6.2 Successor Function
A course $c$ is selectable in state $S$ iff:
1. $c \notin S$ (course not already completed)
2. $\text{prerequisites}(c) \subseteq \text{acquired\_skills}(S)$ (all prerequisites met)
3. $\text{skills}(c) \setminus \text{acquired\_skills}(S) \neq \emptyset$ (teaches at least one new skill)

### 6.3 Goal Test
$$\text{Goal Test}(S) = \text{True} \iff \text{required\_skills}(\text{CareerGoal}) \subseteq \text{acquired\_skills}(S)$$

### 6.4 Cost Function $g(n)$
$$\text{course\_cost}(c) = \text{duration\_hours}(c) + \text{difficulty\_penalty}(c)$$
- Difficulty Penalties: Beginner = $0.0$, Intermediate = $5.0$, Advanced = $10.0$.
- Strictly non-negative: $g(n) \ge 0$.

### 6.5 Admissible Heuristic Function $h(n)$
Let $M = \text{required\_skills}(\text{career}) \setminus \text{acquired\_skills}(S)$ be the missing skills.  
For each missing skill $s \in M$, let $\text{min\_cost}(s) = \min \{ \text{course\_cost}(c) \mid s \in \text{skills}(c) \}$.
$$h(S) = \begin{cases} 0 & \text{if } M = \emptyset \\ \max_{s \in M} \text{min\_cost}(s) & \text{if } M \neq \emptyset \end{cases}$$

> **Proof of Admissibility:** To achieve the goal state, every missing skill $s \in M$ must be acquired by completing at least one course that teaches $s$. Thus, the remaining optimal path cost $h^*(S)$ must be at least the cost of the cheapest course for any single missing skill $s$, so $h(S) \le \max_{s \in M} \text{min\_cost}(s) \le h^*(S)$. Since $h(S) \le h^*(S)$ for all states, $h(S)$ never overestimates the actual remaining cost, guaranteeing that A* finds an optimal path.

---

## 7. ACADEMIC EVALUATION: A* SEARCH VS UNIFORM COST SEARCH (UCS)

Evaluated on identical problem state instances with 32 courses and 6 target career goals:

| Target Career Goal | Algorithm | Total Cost $g(n)$ | Duration (hrs) | Nodes Expanded | Time (ms) | Search Space Reduction |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **AI Engineer (No Skills)** | **A* Search** | **270.0** | **225** | **45,467** | **2608.60** | **67.8% Reduction** |
| | Uniform Cost Search (UCS) | 270.0 | 225 | 141,208 | 6878.18 | Baseline ($h=0$) |
| **Data Scientist (No Skills)** | **A* Search** | **165.0** | **150** | **2,271** | **110.03** | **76.3% Reduction** |
| | Uniform Cost Search (UCS) | 165.0 | 150 | 9,602 | 372.95 | Baseline ($h=0$) |
| **Software Developer** | **A* Search** | **155.0** | **140** | **1,135** | **52.20** | **82.9% Reduction** |
| | Uniform Cost Search (UCS) | 155.0 | 140 | 6,625 | 257.67 | Baseline ($h=0$) |
| **Full-Stack Web Dev** | **A* Search** | **135.0** | **125** | **917** | **42.70** | **73.1% Reduction** |
| | Uniform Cost Search (UCS) | 135.0 | 125 | 3,403 | 130.65 | Baseline ($h=0$) |

---

## 8. INSTALLATION & RUNNING INSTRUCTIONS

### Prerequisites
- Python 3.9+
- Node.js 18+ and npm

### Step 1: Install Dependencies
```bash
# Install backend dependencies
pip install -r backend/requirements.txt

# Install frontend dependencies
cd frontend
npm install
cd ..
```

#### Step 2: Run Tests & Verification
```bash
# Run backend unit tests (24 test scenarios covering A*, heuristics, dataset validator, and study planner)
$env:PYTHONPATH="backend"; python -m unittest discover -s backend/tests

# Run standalone academic evaluation runner
python backend/evaluation_runner.py
```

### Step 3: Launch Full Application
```bash
# Unified Launcher script (starts FastAPI on port 8000 and React UI on port 5173)
python run.py
```

Open browser at: `http://localhost:5173`  
FastAPI Swagger API Documentation: `http://localhost:8000/docs`

---

## 9. COLLEGE VIVA PREPARATION NOTES

1. **Q: Why use A* Search instead of a traditional rule-based recommendation system?**  
   *A:* Rule-based systems use static lists that cannot dynamically adapt to arbitrary student initial skills, missing skill gaps, or multi-prerequisite graph dependencies. A* search dynamically explores the state space of acquired skills and calculates the optimal sequence of courses.

2. **Q: How does the algorithm handle courses with multiple prerequisites?**  
   *A:* At each state $S$, the successor function evaluates whether all prerequisites for a candidate course are contained within `state.acquired_skills(S)`. A course is expanded only when every prerequisite is satisfied.

3. **Q: Is your heuristic admissible? What does admissibility guarantee?**  
   *A:* Yes, $h(S) = \max_{s \in M} \text{min\_cost}(s)$ is admissible because at least one course must be completed for any missing skill $s$, so the true remaining cost $h^*(S)$ is $\ge \text{min\_cost}(s)$. Admissibility guarantees that A* Search will never miss the optimal (lowest cost) learning path.

4. **Q: How does the Study Planner integrate with A* Search?**  
   *A:* The Study Planner directly invokes the genuine A* search engine to obtain the optimal prerequisite-respecting course sequence. It then modularizes each course's actual duration into specific study tasks (concepts, hands-on coding, exercises, mini-projects) and schedules them strictly within the student's specified daily hours and available days.

---

## 10. PROJECT FOLDER STRUCTURE
```
AI-Course-Recommender/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── courses.py          # Course catalog REST endpoints & admin CRUD
│   │   │   ├── careers.py          # Career goal query endpoints
│   │   │   ├── recommendations.py  # A* Recommendation endpoints
│   │   │   ├── study_plan.py       # Personalized study planner endpoints & task progress
│   │   │   ├── students.py         # Student profiles & SQLite progress tracking
│   │   │   └── evaluation.py       # A* vs UCS academic comparison endpoint
│   │   ├── recommender/
│   │   │   ├── state.py            # State representation using completed course IDs
│   │   │   ├── cost.py             # g(n) non-negative cost function
│   │   │   ├── heuristic.py        # h(n) admissible max-missing-skill heuristic
│   │   │   ├── graph.py            # CourseGraph loader & DFS cycle validator
│   │   │   ├── astar.py            # Pure Python A* Search engine from scratch
│   │   │   ├── ucs.py              # Uniform Cost Search (h=0) for benchmarking
│   │   │   └── planner.py          # Personalized timetable scheduler engine
│   │   ├── data/
│   │   │   ├── courses.json        # Authoritative JSON dataset (32 courses)
│   │   │   └── careers.json        # Career goals and required skill mappings
│   │   ├── database.py             # SQLite connection & SQLAlchemy session
│   │   ├── models.py               # SQLAlchemy ORM models
│   │   ├── schemas.py              # Pydantic validation schemas
│   │   └── main.py                 # FastAPI application server
│   ├── tests/
│   │   ├── test_astar.py           # 10 mandated algorithmic scenario tests
│   │   ├── test_validator.py       # Dataset validation error handling tests
│   │   └── test_study_plan.py      # 9 study planner constraint & timetable tests
│   └── evaluation_runner.py        # Standalone benchmark script (A* vs UCS)
├── frontend/                       # Vite + React Web Dashboard
│   ├── src/
│   │   ├── components/             # Visualizer timeline, metric cards, charts, modals
│   │   ├── pages/
│   │   │   ├── LoginPage.jsx       # Student authentication & profile entry
│   │   │   ├── HomePage.jsx        # Project overview & system architecture
│   │   │   ├── ProfilePage.jsx     # Student skills & career goal entry
│   │   │   ├── RecommendationPage.jsx # A* optimal sequence & analytics
│   │   │   ├── StudyPlanPage.jsx   # Personalized weekly timetable & progress
│   │   │   ├── CourseCatalogPage.jsx # Filterable 32-course catalog
│   │   │   ├── ProgressPage.jsx    # Course completion checklist
│   │   │   ├── AdminPage.jsx       # Dataset validator & course management
│   │   │   └── EvaluationPage.jsx  # Academic benchmarking & theory
│   │   └── services/               # Axios API client
├── README.md                       # Comprehensive report & setup guide
└── run.py                          # Cross-platform application launcher
```

