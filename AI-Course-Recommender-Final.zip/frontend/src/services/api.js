import axios from 'axios';

const API_BASE_URL = 'http://localhost:8000/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getCourses = async () => {
  const res = await api.get('/courses');
  return res.data;
};

export const getCourseById = async (id) => {
  const res = await api.get(`/courses/${id}`);
  return res.data;
};

export const createOrUpdateCourse = async (courseData) => {
  const res = await api.post('/courses', courseData);
  return res.data;
};

export const getCareers = async () => {
  const res = await api.get('/careers');
  return res.data;
};

export const generateRecommendation = async (profileData) => {
  const res = await api.post('/recommendations', profileData);
  return res.data;
};

export const createStudentProfile = async (profileData) => {
  const res = await api.post('/students', profileData);
  return res.data;
};

export const getStudentProgress = async (studentId) => {
  const res = await api.get(`/students/${studentId}/progress`);
  return res.data;
};

export const updateStudentProgress = async (studentId, completedCourseIds) => {
  const res = await api.post('/students/progress', {
    student_id: studentId,
    completed_course_ids: completedCourseIds,
  });
  return res.data;
};

export const runComparison = async (profileData) => {
  const res = await api.post('/evaluation/compare', profileData);
  return res.data;
};

export const getHealth = async () => {
  const res = await api.get('/health');
  return res.data;
};

export const getStudyPlan = async (planRequest) => {
  const res = await api.post('/study-plan', planRequest);
  return res.data;
};

export const saveStudyPlanProgress = async (studentId, completedTaskIds) => {
  const res = await api.post('/study-plan/progress', {
    student_id: studentId,
    completed_task_ids: completedTaskIds,
  });
  return res.data;
};

export const getStudyPlanProgress = async (studentId) => {
  const res = await api.get(`/study-plan/progress/${encodeURIComponent(studentId)}`);
  return res.data;
};

export default api;

