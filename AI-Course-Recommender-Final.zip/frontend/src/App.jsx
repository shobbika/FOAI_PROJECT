import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import ProfilePage from './pages/ProfilePage';
import RecommendationPage from './pages/RecommendationPage';
import CourseCatalogPage from './pages/CourseCatalogPage';
import ProgressPage from './pages/ProgressPage';
import AdminPage from './pages/AdminPage';
import EvaluationPage from './pages/EvaluationPage';
import StudyPlanPage from './pages/StudyPlanPage';


export default function App() {
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem('pathfinder_student_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [activePage, setActivePage] = useState('home');
  const [recommendationResult, setRecommendationResult] = useState(null);
  const [profileData, setProfileData] = useState(null);
  const [comparisonResult, setComparisonResult] = useState(null);

  const handleLogin = (userData) => {
    try {
      localStorage.setItem('pathfinder_student_user', JSON.stringify(userData));
    } catch (e) {
      console.error('Failed to save user session:', e);
    }
    setCurrentUser(userData);
    setActivePage('home');
  };

  const handleLogout = () => {
    try {
      localStorage.removeItem('pathfinder_student_user');
    } catch (e) {
      console.error('Failed to clear user session:', e);
    }
    setCurrentUser(null);
    setRecommendationResult(null);
    setProfileData(null);
    setActivePage('home');
  };

  const handleRecommendationGenerated = (result, profile) => {
    setRecommendationResult(result);
    setProfileData(profile);
  };

  // If user is not logged in, display the Student Login Portal
  if (!currentUser) {
    return (
      <div className="app-container">
        <LoginPage onLogin={handleLogin} />
      </div>
    );
  }

  return (
    <div className="app-container">
      <Navbar 
        activePage={activePage} 
        setActivePage={setActivePage} 
        currentUser={currentUser}
        onLogout={handleLogout}
      />

      <main>
        {activePage === 'home' && (
          <HomePage setActivePage={setActivePage} />
        )}

        {activePage === 'profile' && (
          <ProfilePage 
            onRecommendationGenerated={handleRecommendationGenerated}
            setActivePage={setActivePage}
            currentUser={currentUser}
          />
        )}

        {activePage === 'recommendation' && (
          <RecommendationPage 
            recommendationResult={recommendationResult}
            profileData={profileData}
            setActivePage={setActivePage}
            setComparisonResult={setComparisonResult}
          />
        )}

        {activePage === 'study-plan' && (
          <StudyPlanPage 
            currentUser={currentUser}
            profileData={profileData}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'catalog' && (
          <CourseCatalogPage />
        )}


        {activePage === 'progress' && (
          <ProgressPage 
            profileData={profileData}
            onRecommendationGenerated={handleRecommendationGenerated}
            setActivePage={setActivePage}
          />
        )}

        {activePage === 'admin' && (
          <AdminPage />
        )}

        {activePage === 'evaluation' && (
          <EvaluationPage 
            comparisonResult={comparisonResult}
            setComparisonResult={setComparisonResult}
          />
        )}
      </main>

      <footer style={{
        marginTop: '60px',
        paddingTop: '20px',
        borderTop: '1px solid rgba(255,255,255,0.06)',
        textAlign: 'center',
        color: 'var(--text-dim)',
        fontSize: '0.85rem'
      }}>
        Intelligent Course Recommendation & Learning Path System Using A* Search
      </footer>
    </div>
  );
}
