import React, { useEffect, useState } from 'react';
import { Compass, BookOpen, User, BarChart2, CheckCircle2, ShieldCheck, LogOut, GraduationCap, Calendar } from 'lucide-react';
import { getHealth } from '../services/api';

export default function Navbar({ activePage, setActivePage, currentUser, onLogout }) {
  const [health, setHealth] = useState(null);

  useEffect(() => {
    getHealth()
      .then(data => setHealth(data))
      .catch(() => setHealth({ status: 'offline' }));
  }, []);

  const navItems = [
    { id: 'home', label: 'Home', icon: Compass },
    { id: 'profile', label: 'Get Recommendation', icon: User },
    { id: 'study-plan', label: 'My Study Plan', icon: Calendar },
    { id: 'catalog', label: 'Course Catalog', icon: BookOpen },
    { id: 'progress', label: 'Progress Tracker', icon: CheckCircle2 },
    { id: 'evaluation', label: 'Algorithm Evaluation', icon: BarChart2 },
    { id: 'admin', label: 'Dataset Admin', icon: ShieldCheck },
  ];


  return (
    <nav className="navbar">
      <div className="nav-logo" onClick={() => setActivePage('home')} style={{ cursor: 'pointer' }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '10px',
          background: 'linear-gradient(135deg, #6366f1 0%, #06b6d4 100%)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 14px rgba(99, 102, 241, 0.4)'
        }}>
          <Compass size={24} color="#ffffff" />
        </div>
        <div>
          <div>PathFinder <span className="gradient-text">A*</span></div>
          <div style={{ fontSize: '0.7rem', color: 'var(--text-dim)', fontWeight: '400' }}>
            Intelligent Academic Learning System
          </div>
        </div>
      </div>

      <div className="nav-links">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              className={`nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setActivePage(item.id)}
            >
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                <Icon size={16} />
                {item.label}
              </span>
            </button>
          );
        })}
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {health && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            <span style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: health.status === 'healthy' ? '#10b981' : '#ef4444',
              boxShadow: health.status === 'healthy' ? '0 0 8px #10b981' : 'none'
            }} />
            <span style={{ display: 'none', md: 'inline' }}>
              {health.status === 'healthy' ? `A* Valid (${health.courses_count} Courses)` : 'Backend Offline'}
            </span>
          </div>
        )}

        {currentUser && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '10px',
            background: 'rgba(255, 255, 255, 0.05)',
            border: '1px solid var(--border-color)',
            padding: '5px 12px',
            borderRadius: '12px'
          }}>
            <div style={{
              width: '28px',
              height: '28px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #6366f1, #06b6d4)',
              color: '#ffffff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '0.8rem',
              fontWeight: '700'
            }}>
              {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'S'}
            </div>
            <div style={{ fontSize: '0.8rem', lineHeight: '1.2' }}>
              <div style={{ fontWeight: '600', color: '#ffffff' }}>{currentUser.name}</div>
              <div style={{ color: 'var(--text-dim)', fontSize: '0.7rem' }}>
                {currentUser.universityName ? currentUser.universityName.split(' ')[0] : 'Student'}
              </div>
            </div>
            <button
              onClick={onLogout}
              title="Log Out"
              style={{
                background: 'transparent',
                border: 'none',
                color: 'var(--text-muted)',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                padding: '4px',
                marginLeft: '4px',
                borderRadius: '6px',
                transition: 'color 0.2s'
              }}
              onMouseEnter={e => e.currentTarget.style.color = '#f87171'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
            >
              <LogOut size={16} />
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
