import React from 'react';
import { X, Clock, Award, BookOpen, Layers, CheckCircle } from 'lucide-react';

export default function CourseModal({ course, onClose }) {
  if (!course) return null;

  const diffClass = course.difficulty === 'Beginner' ? 'badge-beginner' : course.difficulty === 'Intermediate' ? 'badge-intermediate' : 'badge-advanced';

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.75)',
      backdropFilter: 'blur(8px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px'
    }} onClick={onClose}>
      <div 
        className="glass-panel" 
        style={{ width: '100%', maxWidth: '600px', padding: '30px', position: 'relative' }}
        onClick={e => e.stopPropagation()}
      >
        <button 
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '20px',
            right: '20px',
            background: 'rgba(255, 255, 255, 0.1)',
            border: 'none',
            color: '#ffffff',
            borderRadius: '50%',
            width: '32px',
            height: '32px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer'
          }}
        >
          <X size={18} />
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
          <span style={{ fontFamily: 'monospace', fontWeight: '700', color: '#38bdf8', fontSize: '1rem' }}>
            [{course.id}]
          </span>
          <span className={`badge ${diffClass}`}>{course.difficulty}</span>
          <span className="badge" style={{ background: 'rgba(255,255,255,0.08)', color: 'var(--text-muted)' }}>
            {course.category}
          </span>
        </div>

        <h2 style={{ fontSize: '1.5rem', marginBottom: '12px', color: '#ffffff' }}>{course.name}</h2>
        
        <p style={{ color: 'var(--text-muted)', marginBottom: '24px', fontSize: '0.95rem', lineHeight: '1.6' }}>
          {course.description}
        </p>

        <div className="grid-2" style={{ gap: '16px', marginBottom: '24px' }}>
          <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '10px' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Clock size={14} color="#6366f1" /> Duration & Search Cost
            </div>
            <div style={{ fontSize: '1.1rem', fontWeight: '700', color: '#ffffff' }}>
              {course.duration_hours} hours
            </div>
          </div>

          <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '10px' }}>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginBottom: '4px', display: 'flex', alignItems: 'center', gap: '6px' }}>
              <Award size={14} color="#06b6d4" /> Skills Acquired
            </div>
            <div style={{ fontSize: '0.9rem', color: '#38bdf8', fontWeight: '600' }}>
              {course.skills.join(', ')}
            </div>
          </div>
        </div>

        {/* Prerequisites */}
        <div style={{ marginBottom: '20px' }}>
          <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '8px' }}>Prerequisites:</h4>
          {course.prerequisites.length === 0 ? (
            <span style={{ fontSize: '0.85rem', color: '#34d399' }}>None (Direct Entry Course)</span>
          ) : (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {course.prerequisites.map(p => (
                <span key={p} className="badge badge-skill">{p}</span>
              ))}
            </div>
          )}
        </div>

        {/* Target Careers */}
        {course.careers && course.careers.length > 0 && (
          <div style={{ marginBottom: '20px' }}>
            <h4 style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '8px' }}>Relevant Career Goals:</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
              {course.careers.map(car => (
                <span key={car} className="badge" style={{ background: 'rgba(6, 182, 212, 0.15)', color: '#38bdf8' }}>
                  {car.replace('_', ' ').toUpperCase()}
                </span>
              ))}
            </div>
          </div>
        )}

        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
          <button className="btn-secondary" onClick={onClose}>
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
}
