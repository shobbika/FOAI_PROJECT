import React from 'react';
import { ArrowRight, Clock, Award, CheckCircle, Layers, HelpCircle } from 'lucide-react';

export default function LearningPathVisualizer({ pathSteps, learningPath, onSelectCourse }) {
  if (!pathSteps || pathSteps.length === 0) {
    return (
      <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)' }}>
        <CheckCircle size={48} color="#10b981" style={{ marginBottom: '16px' }} />
        <h3>All Skill Requirements Satisfied!</h3>
        <p>No additional courses are required to reach your target career goal.</p>
      </div>
    );
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
      <h3 style={{ fontSize: '1.25rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
        <Layers color="#6366f1" size={20} />
        A* Optimal Learning Sequence Timeline
      </h3>

      <div style={{ position: 'relative', paddingLeft: '30px' }}>
        {/* Vertical connecting line */}
        <div style={{
          position: 'absolute',
          left: '14px',
          top: '20px',
          bottom: '20px',
          width: '3px',
          background: 'linear-gradient(to bottom, #6366f1, #06b6d4, #10b981)',
          borderRadius: '2px'
        }} />

        {pathSteps.map((step, idx) => {
          const course = learningPath[idx];
          const diffClass = step.difficulty === 'Beginner' ? 'badge-beginner' : step.difficulty === 'Intermediate' ? 'badge-intermediate' : 'badge-advanced';

          return (
            <div key={step.course_id} style={{ position: 'relative', marginBottom: '24px' }}>
              {/* Timeline Step Node Circle */}
              <div style={{
                position: 'absolute',
                left: '-30px',
                top: '16px',
                width: '28px',
                height: '28px',
                borderRadius: '50%',
                background: '#111827',
                border: '3px solid #6366f1',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#ffffff',
                fontWeight: '700',
                fontSize: '0.8rem',
                zIndex: 2,
                boxShadow: '0 0 12px rgba(99, 102, 241, 0.5)'
              }}>
                {idx + 1}
              </div>

              {/* Step Card */}
              <div 
                className="glass-panel" 
                style={{ padding: '20px', cursor: 'pointer' }}
                onClick={() => onSelectCourse && onSelectCourse(course)}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '10px' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
                      <span style={{ fontFamily: 'monospace', fontWeight: '700', color: '#38bdf8', fontSize: '0.9rem' }}>
                        [{step.course_id}]
                      </span>
                      <h4 style={{ fontSize: '1.1rem', color: '#ffffff' }}>{step.course_name}</h4>
                      <span className={`badge ${diffClass}`}>{step.difficulty}</span>
                    </div>

                    <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', marginBottom: '12px' }}>
                      {course ? course.description : ''}
                    </p>
                  </div>

                  {/* Search Evaluation Score Pills */}
                  <div style={{ 
                    display: 'flex', 
                    gap: '12px', 
                    background: 'rgba(0,0,0,0.3)', 
                    padding: '8px 14px', 
                    borderRadius: '10px',
                    border: '1px solid rgba(255,255,255,0.05)',
                    fontSize: '0.8rem'
                  }}>
                    <div>
                      <div style={{ color: 'var(--text-dim)', fontSize: '0.7rem' }}>Cost g(n)</div>
                      <div style={{ fontWeight: '700', color: '#a5b4fc' }}>{step.accumulated_g}</div>
                    </div>
                    <div style={{ borderLeft: '1px solid rgba(255,255,255,0.1)', paddingLeft: '8px' }}>
                      <div style={{ color: 'var(--text-dim)', fontSize: '0.7rem' }}>Est h(n)</div>
                      <div style={{ fontWeight: '700', color: '#38bdf8' }}>{step.heuristic_h}</div>
                    </div>
                    <div style={{ borderLeft: '1px solid rgba(255,255,255,0.1)', paddingLeft: '8px' }}>
                      <div style={{ color: 'var(--text-dim)', fontSize: '0.7rem' }}>Total f(n)</div>
                      <div style={{ fontWeight: '700', color: '#34d399' }}>{step.total_f}</div>
                    </div>
                  </div>
                </div>

                <div style={{ 
                  display: 'flex', 
                  justify: 'space-between', 
                  alignItems: 'center', 
                  marginTop: '12px',
                  paddingTop: '12px',
                  borderTop: '1px solid rgba(255,255,255,0.06)',
                  flexWrap: 'wrap',
                  gap: '12px',
                  fontSize: '0.85rem'
                }}>
                  <div style={{ display: 'flex', gap: '16px', color: 'var(--text-muted)' }}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Clock size={14} color="#6366f1" /> {step.duration_hours} hrs
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                      <Award size={14} color="#06b6d4" /> Teaches: {step.skills_acquired.join(', ')}
                    </span>
                  </div>

                  {step.prerequisites.length > 0 && (
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)' }}>
                      Prerequisites met: {step.prerequisites.map(p => (
                        <span key={p} className="badge badge-skill" style={{ margin: '0 2px', fontSize: '0.7rem' }}>{p}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
