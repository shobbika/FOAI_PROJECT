import React from 'react';
import { Cpu, Zap, CheckCircle2, TrendingDown } from 'lucide-react';

export default function ComparisonChart({ comparisonData }) {
  if (!comparisonData) return null;

  const { astar_metrics, ucs_metrics, nodes_saved_by_astar, percentage_node_reduction, is_path_cost_identical } = comparisonData;

  const maxNodes = Math.max(astar_metrics.nodes_expanded, ucs_metrics.nodes_expanded, 1);
  const ucsBarWidth = 100;
  const astarBarWidth = Math.max(5, Math.round((astar_metrics.nodes_expanded / maxNodes) * 100));

  return (
    <div className="glass-panel" style={{ padding: '30px', marginTop: '30px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem', color: '#ffffff', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <Zap color="#f59e0b" size={22} />
            Algorithm Evaluation: A* Search vs Uniform Cost Search (UCS)
          </h3>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Comparing search efficiency on identical problem state instance for career goal: <span style={{ color: '#38bdf8', fontWeight: '600' }}>{comparisonData.career_title}</span>
          </p>
        </div>

        <div className="badge badge-beginner" style={{ fontSize: '0.85rem', padding: '6px 14px' }}>
          <TrendingDown size={16} style={{ marginRight: '6px' }} />
          A* reduced search space by {percentage_node_reduction}%
        </div>
      </div>

      {/* Visual Bar Comparison */}
      <div style={{ background: 'rgba(0,0,0,0.3)', padding: '24px', borderRadius: '12px', marginBottom: '24px' }}>
        <h4 style={{ fontSize: '0.95rem', marginBottom: '16px', color: 'var(--text-muted)' }}>State Space Node Expansion Comparison:</h4>
        
        {/* UCS Bar */}
        <div style={{ marginBottom: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '6px' }}>
            <span>Uniform Cost Search (Dijkstra) [h(n) = 0]</span>
            <span style={{ fontWeight: '700', color: '#f87171' }}>{ucs_metrics.nodes_expanded} nodes ({ucs_metrics.execution_time_ms} ms)</span>
          </div>
          <div style={{ height: '14px', background: 'rgba(255,255,255,0.08)', borderRadius: '7px', overflow: 'hidden' }}>
            <div style={{
              width: `${ucsBarWidth}%`,
              height: '100%',
              background: 'linear-gradient(90deg, #ef4444 0%, #f59e0b 100%)',
              borderRadius: '7px'
            }} />
          </div>
        </div>

        {/* A* Bar */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '6px' }}>
            <span>A* Search [f(n) = g(n) + h(n)]</span>
            <span style={{ fontWeight: '700', color: '#34d399' }}>{astar_metrics.nodes_expanded} nodes ({astar_metrics.execution_time_ms} ms)</span>
          </div>
          <div style={{ height: '14px', background: 'rgba(255,255,255,0.08)', borderRadius: '7px', overflow: 'hidden' }}>
            <div style={{
              width: `${astarBarWidth}%`,
              height: '100%',
              background: 'linear-gradient(90deg, #6366f1 0%, #10b981 100%)',
              borderRadius: '7px'
            }} />
          </div>
        </div>
      </div>

      {/* Detailed Side by Side Metric Table */}
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9rem' }}>
        <thead>
          <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', textAlign: 'left', color: 'var(--text-muted)' }}>
            <th style={{ padding: '10px' }}>Evaluation Metric</th>
            <th style={{ padding: '10px', color: '#6366f1' }}>A* Search</th>
            <th style={{ padding: '10px', color: '#f59e0b' }}>Uniform Cost Search (UCS)</th>
            <th style={{ padding: '10px', color: '#10b981' }}>Optimality / Savings</th>
          </tr>
        </thead>
        <tbody>
          <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
            <td style={{ padding: '12px 10px', color: '#ffffff', fontWeight: '500' }}>Total Path Cost g(n)</td>
            <td style={{ padding: '12px 10px', fontWeight: '700', color: '#a5b4fc' }}>{astar_metrics.total_cost}</td>
            <td style={{ padding: '12px 10px', fontWeight: '700', color: '#fde68a' }}>{ucs_metrics.total_cost}</td>
            <td style={{ padding: '12px 10px', color: '#34d399', fontWeight: '600' }}>
              {is_path_cost_identical ? 'Identical (Guaranteed Optimal)' : 'Cost Difference Detected'}
            </td>
          </tr>
          <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
            <td style={{ padding: '12px 10px', color: '#ffffff', fontWeight: '500' }}>Nodes Expanded</td>
            <td style={{ padding: '12px 10px', fontWeight: '700', color: '#a5b4fc' }}>{astar_metrics.nodes_expanded}</td>
            <td style={{ padding: '12px 10px', fontWeight: '700', color: '#fde68a' }}>{ucs_metrics.nodes_expanded}</td>
            <td style={{ padding: '12px 10px', color: '#34d399', fontWeight: '600' }}>
              Saved {nodes_saved_by_astar} nodes ({percentage_node_reduction}% reduction)
            </td>
          </tr>
          <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
            <td style={{ padding: '12px 10px', color: '#ffffff', fontWeight: '500' }}>Execution Time</td>
            <td style={{ padding: '12px 10px', fontWeight: '700', color: '#a5b4fc' }}>{astar_metrics.execution_time_ms} ms</td>
            <td style={{ padding: '12px 10px', fontWeight: '700', color: '#fde68a' }}>{ucs_metrics.execution_time_ms} ms</td>
            <td style={{ padding: '12px 10px', color: '#38bdf8' }}>
              A* is faster due to heuristic pruning
            </td>
          </tr>
          <tr>
            <td style={{ padding: '12px 10px', color: '#ffffff', fontWeight: '500' }}>Total Course Sequence</td>
            <td style={{ padding: '12px 10px' }}>{astar_metrics.path_length} courses</td>
            <td style={{ padding: '12px 10px' }}>{ucs_metrics.path_length} courses</td>
            <td style={{ padding: '12px 10px', color: '#34d399' }}>Same Course Count</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
}
