import React from 'react';
import { Cpu, Clock, Calendar, DollarSign, Activity } from 'lucide-react';

export default function MetricCards({ result }) {
  if (!result) return null;

  const metrics = [
    {
      title: 'Total Search Cost g(n)',
      value: result.total_cost,
      subtitle: 'Duration + Difficulty Penalties',
      icon: DollarSign,
      color: '#6366f1'
    },
    {
      title: 'State Nodes Expanded',
      value: result.nodes_expanded,
      subtitle: 'A* Closed Set Size',
      icon: Cpu,
      color: '#06b6d4'
    },
    {
      title: 'Total Study Hours',
      value: `${result.total_duration_hours} hrs`,
      subtitle: `${result.learning_path.length} Courses Sequence`,
      icon: Clock,
      color: '#10b981'
    },
    {
      title: 'Estimated Duration',
      value: `${result.estimated_weeks} wks`,
      subtitle: 'Based on weekly study commitment',
      icon: Calendar,
      color: '#f59e0b'
    },
  ];

  return (
    <div className="grid-4" style={{ marginBottom: '30px' }}>
      {metrics.map((m, i) => {
        const Icon = m.icon;
        return (
          <div key={i} className="glass-panel" style={{ padding: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '12px' }}>
              <span style={{ fontSize: '0.85rem', color: 'var(--text-muted)', fontWeight: '500' }}>{m.title}</span>
              <div style={{
                width: '34px',
                height: '34px',
                borderRadius: '8px',
                background: `${m.color}20`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}>
                <Icon size={18} color={m.color} />
              </div>
            </div>
            <div style={{ fontSize: '1.75rem', fontWeight: '800', color: '#ffffff', marginBottom: '4px' }}>
              {m.value}
            </div>
            <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
              {m.subtitle}
            </div>
          </div>
        );
      })}
    </div>
  );
}
