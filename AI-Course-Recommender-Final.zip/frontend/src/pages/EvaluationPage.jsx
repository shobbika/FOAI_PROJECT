import React, { useState, useEffect } from 'react';
import { BarChart2, Zap, Play, CheckCircle2, Cpu } from 'lucide-react';
import { getCareers, runComparison } from '../services/api';
import ComparisonChart from '../components/ComparisonChart';

export default function EvaluationPage({ comparisonResult, setComparisonResult }) {
  const [careers, setCareers] = useState([]);
  const [selectedCareer, setSelectedCareer] = useState('ai_engineer');
  const [initialSkills, setInitialSkills] = useState('Python Programming');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getCareers().then(data => setCareers(data)).catch(console.error);
    if (!comparisonResult) {
      handleTriggerBenchmark('ai_engineer', ['Python Programming']);
    }
  }, []);

  const handleTriggerBenchmark = async (careerId = selectedCareer, skillsList = null) => {
    setLoading(true);
    const skillsToUse = skillsList !== null ? skillsList : initialSkills.split(',').map(s => s.trim()).filter(Boolean);
    try {
      const data = await runComparison({
        career_id: careerId,
        current_skills: skillsToUse,
        interests: [],
        available_hours_per_week: 10
      });
      setComparisonResult(data);
    } catch (err) {
      alert('Error running benchmark: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>
          Academic Algorithm Evaluation: <span className="gradient-text">A* vs Uniform Cost Search</span>
        </h1>
        <p style={{ color: 'var(--text-muted)' }}>
          Benchmarking search space node expansion reduction using admissible heuristic h(n)
        </p>
      </div>

      {/* Control Bar */}
      <div className="glass-panel" style={{ padding: '24px', marginBottom: '30px' }}>
        <div className="grid-3" style={{ alignItems: 'flex-end', gap: '16px' }}>
          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Select Target Career Problem Instance</label>
            <select
              value={selectedCareer}
              onChange={e => setSelectedCareer(e.target.value)}
              style={{ width: '100%', padding: '10px', borderRadius: '8px', background: '#111827', border: '1px solid var(--border-color)', color: '#fff' }}
            >
              {careers.map(car => (
                <option key={car.id} value={car.id}>{car.title}</option>
              ))}
            </select>
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Initial Student Skills (comma separated)</label>
            <input
              type="text"
              value={initialSkills}
              onChange={e => setInitialSkills(e.target.value)}
              placeholder="e.g. Python Programming"
              style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }}
            />
          </div>

          <button className="btn-primary" onClick={() => handleTriggerBenchmark()} disabled={loading} style={{ padding: '12px 20px', justifyContent: 'center' }}>
            <Play size={16} /> {loading ? 'Running Benchmarks...' : 'Run Comparative Benchmark'}
          </button>
        </div>
      </div>

      {/* Comparison Visual Chart */}
      {comparisonResult && (
        <ComparisonChart comparisonData={comparisonResult} />
      )}

      {/* Algorithm Evaluation & Theory Box */}
      <div className="glass-panel" style={{ padding: '28px', marginTop: '30px', borderLeft: '4px solid #06b6d4' }}>
        <h3 style={{ fontSize: '1.2rem', marginBottom: '12px', color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Zap color="#06b6d4" size={20} /> Algorithm Search Theory & Academic Evaluation
        </h3>
        <ul style={{ paddingLeft: '20px', color: 'var(--text-muted)', fontSize: '0.95rem', lineHeight: '1.8' }}>
          <li><strong>Why does UCS expand more nodes than A*?</strong> Uniform Cost Search expands nodes purely based on accumulated cost g(n) in all directions (concentric circles), whereas A* uses the heuristic h(n) to direct the search toward the goal, expanding significantly fewer states.</li>
          <li><strong>Why are path costs identical?</strong> Because our heuristic <code style={{ color: '#38bdf8' }}>h(S) = max_(s ∈ MissingSkills) [ min_cost(s) ]</code> is strictly admissible (<code style={{ color: '#34d399' }}>h(S) ≤ h*(S)</code>), A* is mathematically guaranteed to find the same globally optimal path cost as UCS (Dijkstra).</li>
          <li><strong>Graph vs Tree Search:</strong> We maintain a Closed Set of visited states to prevent cycles and duplicate node expansions.</li>
        </ul>
      </div>
    </div>
  );
}
