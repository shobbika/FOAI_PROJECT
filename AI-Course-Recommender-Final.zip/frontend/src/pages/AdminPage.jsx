import React, { useState, useEffect } from 'react';
import { ShieldCheck, Plus, CheckCircle, AlertTriangle, RefreshCw } from 'lucide-react';
import { getCourses, getHealth, createOrUpdateCourse } from '../services/api';

export default function AdminPage() {
  const [courses, setCourses] = useState([]);
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  // Course Add/Edit Form State
  const [courseId, setCourseId] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Computer Science');
  const [skills, setSkills] = useState('Python Programming');
  const [prerequisites, setPrerequisites] = useState('');
  const [difficulty, setDifficulty] = useState('Beginner');
  const [duration, setDuration] = useState(15);
  const [careers, setCareers] = useState('ai_engineer');

  const refreshData = () => {
    getCourses().then(data => setCourses(data));
    getHealth().then(data => setHealth(data));
  };

  useEffect(() => {
    refreshData();
  }, []);

  const handleSaveCourse = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage('');
    setError('');

    const courseData = {
      id: courseId.trim(),
      name: name.trim(),
      description: description.trim(),
      category: category.trim(),
      skills: skills.split(',').map(s => s.trim()).filter(Boolean),
      prerequisites: prerequisites.split(',').map(s => s.trim()).filter(Boolean),
      difficulty: difficulty,
      duration_hours: parseFloat(duration),
      careers: careers.split(',').map(c => c.trim()).filter(Boolean),
      interests: [category, difficulty]
    };

    try {
      await createOrUpdateCourse(courseData);
      setMessage(`Course '${courseId}' saved & dataset validated successfully!`);
      refreshData();
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to save course.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '950px', margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>
          Dataset Admin & <span className="gradient-text">Validation Manager</span>
        </h1>
        <p style={{ color: 'var(--text-muted)' }}>
          Inspect knowledge base integrity, cyclic dependencies, and dynamically add courses
        </p>
      </div>

      {health && (
        <div className="glass-panel" style={{ padding: '20px', marginBottom: '28px', borderLeft: health.dataset_valid ? '4px solid #10b981' : '4px solid #ef4444' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {health.dataset_valid ? (
              <CheckCircle size={24} color="#10b981" />
            ) : (
              <AlertTriangle size={24} color="#ef4444" />
            )}
            <div>
              <h3 style={{ fontSize: '1.1rem', color: '#ffffff' }}>
                Dataset Validation Status: {health.dataset_valid ? 'VALID (No Cycles or Malformed Records)' : 'INVALID'}
              </h3>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                {health.dataset_message} | Total Courses: {health.courses_count} | Target Careers: {health.careers_count}
              </p>
            </div>
          </div>
        </div>
      )}

      {message && <div className="glass-panel" style={{ padding: '16px', borderColor: '#10b981', color: '#34d399', marginBottom: '20px' }}>{message}</div>}
      {error && <div className="glass-panel" style={{ padding: '16px', borderColor: '#ef4444', color: '#f87171', marginBottom: '20px' }}>{error}</div>}

      {/* Add / Edit Course Form */}
      <form onSubmit={handleSaveCourse} className="glass-panel" style={{ padding: '28px', marginBottom: '32px' }}>
        <h3 style={{ fontSize: '1.2rem', marginBottom: '20px', color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Plus size={20} color="#6366f1" /> Add / Modify Knowledge Base Course
        </h3>

        <div className="grid-3" style={{ marginBottom: '16px' }}>
          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Course ID (e.g. CS105)</label>
            <input type="text" value={courseId} onChange={e => setCourseId(e.target.value)} required style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Course Name</label>
            <input type="text" value={name} onChange={e => setName(e.target.value)} required style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Category</label>
            <input type="text" value={category} onChange={e => setCategory(e.target.value)} required style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>
        </div>

        <div style={{ marginBottom: '16px' }}>
          <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Description</label>
          <textarea value={description} onChange={e => setDescription(e.target.value)} required rows={2} style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff', fontFamily: 'inherit' }} />
        </div>

        <div className="grid-3" style={{ marginBottom: '20px' }}>
          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Skills Taught (comma separated)</label>
            <input type="text" value={skills} onChange={e => setSkills(e.target.value)} required style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Prerequisites (comma separated)</label>
            <input type="text" value={prerequisites} onChange={e => setPrerequisites(e.target.value)} placeholder="e.g. Python Programming" style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Difficulty</label>
            <select value={difficulty} onChange={e => setDifficulty(e.target.value)} style={{ width: '100%', padding: '10px', borderRadius: '8px', background: '#111827', border: '1px solid var(--border-color)', color: '#fff' }}>
              <option value="Beginner">Beginner (Penalty: 0)</option>
              <option value="Intermediate">Intermediate (Penalty: +5)</option>
              <option value="Advanced">Advanced (Penalty: +10)</option>
            </select>
          </div>
        </div>

        <div className="grid-2" style={{ marginBottom: '24px' }}>
          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Duration (Hours)</label>
            <input type="number" value={duration} onChange={e => setDuration(e.target.value)} required min="1" style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>

          <div>
            <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)', display: 'block', marginBottom: '6px' }}>Target Career Tag(s)</label>
            <input type="text" value={careers} onChange={e => setCareers(e.target.value)} placeholder="e.g. ai_engineer, data_scientist" style={{ width: '100%', padding: '10px', borderRadius: '8px', background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-color)', color: '#fff' }} />
          </div>
        </div>

        <button type="submit" className="btn-primary" disabled={loading}>
          {loading ? 'Validating Dataset...' : 'Save Course & Re-validate Dataset'}
        </button>
      </form>
    </div>
  );
}
