import React, { useState, useEffect } from 'react';
import { User, Target, Clock, BookOpen, Sparkles, ArrowRight, Loader2, GraduationCap, Building2 } from 'lucide-react';
import { getCareers, getCourses, generateRecommendation } from '../services/api';

export default function ProfilePage({ onRecommendationGenerated, setActivePage, currentUser }) {
  const [careers, setCareers] = useState([]);
  const [allSkills, setAllSkills] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form State
  const [name, setName] = useState(currentUser?.name || 'Alex Student');
  const [selectedCareer, setSelectedCareer] = useState('ai_engineer');
  const [knowledgeLevel, setKnowledgeLevel] = useState('Beginner');
  const [availableHours, setAvailableHours] = useState(10);
  const [selectedSkills, setSelectedSkills] = useState(['Python Programming']);
  const [interests, setInterests] = useState(['Machine Learning', 'Generative AI']);

  useEffect(() => {
    if (currentUser?.name) {
      setName(currentUser.name);
    }
  }, [currentUser]);

  useEffect(() => {
    // Fetch careers and unique skills from courses
    Promise.all([getCareers(), getCourses()])
      .then(([careerData, courseData]) => {
        setCareers(careerData);
        const skillSet = new Set();
        courseData.forEach(c => c.skills.forEach(s => skillSet.add(s)));
        setAllSkills(Array.from(skillSet).sort());
      })
      .catch(err => setError('Failed to load careers and courses data from backend.'));
  }, []);

  const handleSkillToggle = (skill) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const handleInterestToggle = (interest) => {
    if (interests.includes(interest)) {
      setInterests(interests.filter(i => i !== interest));
    } else {
      setInterests([...interests, interest]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const profileData = {
      student_name: name,
      current_skills: selectedSkills,
      knowledge_level: knowledgeLevel,
      career_id: selectedCareer,
      interests: interests,
      available_hours_per_week: parseFloat(availableHours)
    };

    try {
      const result = await generateRecommendation(profileData);
      onRecommendationGenerated(result, profileData);
      setActivePage('recommendation');
    } catch (err) {
      setError(err.response?.data?.detail || 'Error calculating A* recommendation.');
    } finally {
      setLoading(false);
    }
  };

  const popularInterests = ['Python', 'Machine Learning', 'Deep Learning', 'Generative AI', 'Data Science', 'Web', 'React', 'DevOps', 'Cybersecurity', 'Cloud'];

  return (
    <div style={{ maxWidth: '850px', margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>
          Student Skill & Career <span className="gradient-text">Profile Entry</span>
        </h1>
        <p style={{ color: 'var(--text-muted)' }}>
          Configure your current skills, knowledge level, and target career goal for the A* search agent
        </p>
      </div>

      {currentUser && (
        <div className="glass-panel" style={{ padding: '16px 22px', marginBottom: '24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px', borderLeft: '4px solid #6366f1' }}>
          <div>
            <div style={{ fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--text-dim)' }}>
              Authenticated Student Profile
            </div>
            <div style={{ fontWeight: '700', color: '#ffffff', fontSize: '1.1rem', marginTop: '2px' }}>
              {currentUser.name}
            </div>
            <div style={{ fontSize: '0.85rem', color: '#38bdf8', display: 'flex', alignItems: 'center', gap: '8px', marginTop: '4px' }}>
              <span><GraduationCap size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '4px' }} />{currentUser.courseName} ({currentUser.courseDuration})</span>
              <span>•</span>
              <span><Building2 size={14} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '4px' }} />{currentUser.universityName}</span>
            </div>
          </div>
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textAlign: 'right' }}>
            <div>{currentUser.email}</div>
            <div>{currentUser.contactNo}</div>
          </div>
        </div>
      )}

      {error && (
        <div className="glass-panel" style={{ padding: '16px', borderColor: '#ef4444', color: '#f87171', marginBottom: '24px' }}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="glass-panel" style={{ padding: '36px' }}>
        {/* Name & Knowledge Level */}
        <div className="grid-2" style={{ marginBottom: '24px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>
              Student Name / Nickname
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              required
              style={{
                width: '100%',
                padding: '12px 16px',
                borderRadius: '8px',
                background: 'rgba(0,0,0,0.4)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontFamily: 'inherit'
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>
              Knowledge Level
            </label>
            <div style={{ display: 'flex', gap: '8px' }}>
              {['Beginner', 'Intermediate', 'Advanced'].map(lvl => (
                <button
                  key={lvl}
                  type="button"
                  className={knowledgeLevel === lvl ? 'badge badge-beginner' : 'btn-secondary'}
                  style={{ flex: 1, padding: '10px', justifyContent: 'center', cursor: 'pointer' }}
                  onClick={() => setKnowledgeLevel(lvl)}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Target Career Goal */}
        <div style={{ marginBottom: '28px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>
            Target Career Goal (A* Search Goal State)
          </label>
          <div className="grid-3" style={{ gap: '12px' }}>
            {careers.map(car => {
              const isSelected = selectedCareer === car.id;
              return (
                <div
                  key={car.id}
                  onClick={() => setSelectedCareer(car.id)}
                  style={{
                    padding: '14px',
                    borderRadius: '10px',
                    border: isSelected ? '2px solid #6366f1' : '1px solid var(--border-color)',
                    background: isSelected ? 'rgba(99, 102, 241, 0.15)' : 'rgba(0,0,0,0.2)',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                >
                  <div style={{ fontWeight: '700', color: isSelected ? '#ffffff' : 'var(--text-main)', fontSize: '0.95rem' }}>
                    {car.title}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '4px' }}>
                    Requires {car.required_skills.length} skills
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Available Weekly Hours */}
        <div style={{ marginBottom: '28px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <label style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>
              Available Study Hours Per Week
            </label>
            <span style={{ color: '#38bdf8', fontWeight: '700' }}>{availableHours} hours / week</span>
          </div>
          <input
            type="range"
            min="2"
            max="40"
            step="1"
            value={availableHours}
            onChange={e => setAvailableHours(e.target.value)}
            style={{ width: '100%', accentColor: '#6366f1' }}
          />
        </div>

        {/* Already Acquired Skills Multi-Select */}
        <div style={{ marginBottom: '28px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>
            Current Acquired Skills (Initial State Initializer):
          </label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px', maxH: '180px', overflowY: 'auto', padding: '12px', background: 'rgba(0,0,0,0.3)', borderRadius: '10px' }}>
            {allSkills.map(skill => {
              const isChecked = selectedSkills.includes(skill);
              return (
                <button
                  key={skill}
                  type="button"
                  onClick={() => handleSkillToggle(skill)}
                  className={isChecked ? 'badge badge-skill' : 'badge'}
                  style={{
                    background: isChecked ? 'rgba(99,102,241,0.25)' : 'rgba(255,255,255,0.05)',
                    color: isChecked ? '#a5b4fc' : 'var(--text-dim)',
                    border: isChecked ? '1px solid #6366f1' : '1px solid rgba(255,255,255,0.08)',
                    cursor: 'pointer',
                    padding: '6px 12px'
                  }}
                >
                  {isChecked ? '✓ ' : '+ '} {skill}
                </button>
              );
            })}
          </div>
        </div>

        {/* Interests Selection */}
        <div style={{ marginBottom: '32px' }}>
          <label style={{ display: 'block', marginBottom: '8px', fontSize: '0.9rem', color: 'var(--text-muted)' }}>
            Learning Interests (Secondary Tie-Breaker Preference):
          </label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {popularInterests.map(interest => {
              const isSelected = interests.includes(interest);
              return (
                <button
                  key={interest}
                  type="button"
                  onClick={() => handleInterestToggle(interest)}
                  className="badge"
                  style={{
                    background: isSelected ? 'rgba(6, 182, 212, 0.2)' : 'rgba(255,255,255,0.05)',
                    color: isSelected ? '#38bdf8' : 'var(--text-dim)',
                    border: isSelected ? '1px solid #06b6d4' : '1px solid rgba(255,255,255,0.08)',
                    cursor: 'pointer'
                  }}
                >
                  {interest}
                </button>
              );
            })}
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="btn-primary"
          disabled={loading}
          style={{ width: '100%', padding: '16px', justifyContent: 'center', fontSize: '1.05rem' }}
        >
          {loading ? (
            <>
              <Loader2 className="spin" size={20} />
              Executing A* Search Algorithm...
            </>
          ) : (
            <>
              Generate Personalized Learning Path <ArrowRight size={20} />
            </>
          )}
        </button>
      </form>
    </div>
  );
}
