import React from 'react';
import { Compass, Cpu, Target, Award, ArrowRight, Layers, ShieldCheck, Zap } from 'lucide-react';

export default function HomePage({ setActivePage }) {
  const architecturalPrinciples = [
    { title: 'Intelligent Agents', desc: 'Goal-based problem-solving agent designing optimal curriculum pathways.' },
    { title: 'State-Space Search', desc: 'States represented as completed course sets; actions as prerequisite-valid courses.' },
    { title: 'Informed A* Search', desc: 'Evaluation function f(n) = g(n) + h(n) combining path cost and heuristic estimate.' },
    { title: 'Admissible Heuristic', desc: 'Lower-bound estimated cost to acquire missing career skills guaranteeing optimality.' },
    { title: 'Knowledge Representation', desc: 'Structured JSON course graph with multi-prerequisite DAG dependencies.' },
    { title: 'Algorithm Evaluation', desc: 'Comparative benchmarking against Uniform Cost Search (UCS / Dijkstra).' },
  ];

  return (
    <div>
      {/* Hero Banner */}
      <div className="glass-panel" style={{ padding: '60px 40px', textAlign: 'center', marginBottom: '40px', position: 'relative', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute',
          top: '-50%',
          left: '50%',
          transform: 'translateX(-50%)',
          width: '600px',
          height: '400px',
          background: 'radial-gradient(circle, rgba(99,102,241,0.25) 0%, transparent 70%)',
          pointerEvents: 'none'
        }} />

        <span className="badge badge-beginner" style={{ marginBottom: '16px', fontSize: '0.85rem' }}>
          AI-Based Intelligent Learning Path System
        </span>

        <h1 style={{ fontSize: '2.75rem', fontWeight: '800', lineHeight: '1.2', marginBottom: '20px', maxWidth: '900px', margin: '0 auto 20px auto' }}>
          Personalized Course Recommendation & Learning Path System Using <span className="gradient-text">A* Search</span>
        </h1>

        <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)', maxWidth: '750px', margin: '0 auto 32px auto', lineHeight: '1.7' }}>
          An intelligent goal-driven recommendation agent that formulates career goal search spaces, respects complex course multi-prerequisites, and calculates the optimal sequence of courses using a strictly admissible A* heuristic algorithm.
        </p>

        <div style={{ display: 'flex', gap: '16px', justifyContent: 'center' }}>
          <button className="btn-primary" onClick={() => setActivePage('profile')}>
            Start Recommendation Engine <ArrowRight size={18} />
          </button>
          <button className="btn-secondary" onClick={() => setActivePage('evaluation')}>
            View A* vs UCS Benchmarks <Zap size={18} color="#f59e0b" />
          </button>
        </div>
      </div>

      {/* Core Architectural & AI Principles Grid */}
      <div style={{ marginBottom: '40px' }}>
        <h2 style={{ fontSize: '1.75rem', marginBottom: '8px', textAlign: 'center' }}>
          Core System Architecture & Intelligent Search Principles
        </h2>
        <p style={{ textAlign: 'center', color: 'var(--text-muted)', marginBottom: '32px' }}>
          Demonstrating state-space formulation, admissible heuristics, and informed A* pathfinding
        </p>

        <div className="grid-3">
          {architecturalPrinciples.map((item, idx) => (
            <div key={idx} className="glass-panel" style={{ padding: '24px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '12px' }}>
                <div style={{
                  width: '32px',
                  height: '32px',
                  borderRadius: '8px',
                  background: 'rgba(99, 102, 241, 0.2)',
                  color: '#a5b4fc',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: '700',
                  fontSize: '0.85rem'
                }}>
                  0{idx + 1}
                </div>
                <h3 style={{ fontSize: '1.1rem', color: '#ffffff' }}>{item.title}</h3>
              </div>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
                {item.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Mathematical Formulation Callout */}
      <div className="glass-panel" style={{ padding: '32px', borderLeft: '4px solid #6366f1' }}>
        <h3 style={{ fontSize: '1.25rem', marginBottom: '12px', color: '#ffffff' }}>
          Mathematical A* Search Formulation:
        </h3>
        <div style={{ background: 'rgba(0,0,0,0.4)', padding: '16px 24px', borderRadius: '8px', fontFamily: 'monospace', fontSize: '1rem', color: '#38bdf8', marginBottom: '12px' }}>
          f(S) = g(S) + h(S)
        </div>
        <ul style={{ paddingLeft: '20px', color: 'var(--text-muted)', fontSize: '0.95rem', lineHeight: '1.8' }}>
          <li><strong>g(S) (Path Cost):</strong> Accumulated cost of completed courses: <code style={{ color: '#a5b4fc' }}>duration_hours + difficulty_penalty</code>.</li>
          <li><strong>h(S) (Admissible Heuristic):</strong> Lower-bound remaining cost: <code style={{ color: '#a5b4fc' }}>max_(s ∈ MissingSkills) [ min_cost(s) ]</code>.</li>
          <li><strong>Optimality Guarantee:</strong> Since <code style={{ color: '#34d399' }}>h(S) ≤ h*(S)</code> for all states, A* is mathematically proven to find the lowest-cost learning path.</li>
        </ul>
      </div>
    </div>
  );
}
