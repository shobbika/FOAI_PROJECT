import React, { useState, useEffect } from 'react';
import { BookOpen, Search, Filter, Clock, Award } from 'lucide-react';
import { getCourses } from '../services/api';
import CourseModal from '../components/CourseModal';

export default function CourseCatalogPage() {
  const [courses, setCourses] = useState([]);
  const [search, setSearch] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedCourse, setSelectedCourse] = useState(null);

  useEffect(() => {
    getCourses().then(data => setCourses(data)).catch(console.error);
  }, []);

  const categories = ['All', ...Array.from(new Set(courses.map(c => c.category)))];

  const filteredCourses = courses.filter(c => {
    const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
                          c.id.toLowerCase().includes(search.toLowerCase()) ||
                          c.skills.some(s => s.toLowerCase().includes(search.toLowerCase()));
    const matchesDiff = selectedDifficulty === 'All' || c.difficulty === selectedDifficulty;
    const matchesCat = selectedCategory === 'All' || c.category === selectedCategory;
    return matchesSearch && matchesDiff && matchesCat;
  });

  return (
    <div>
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>
          Knowledge Base <span className="gradient-text">Course Catalog</span>
        </h1>
        <p style={{ color: 'var(--text-muted)' }}>
          Explore all 30+ validated courses, multi-prerequisite relationships, and skill mappings
        </p>
      </div>

      {/* Filter Bar */}
      <div className="glass-panel" style={{ padding: '20px', marginBottom: '30px' }}>
        <div className="grid-3" style={{ gap: '16px', alignItems: 'center' }}>
          {/* Search Box */}
          <div style={{ position: 'relative' }}>
            <Search size={18} color="var(--text-muted)" style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)' }} />
            <input
              type="text"
              placeholder="Search course title, ID, or skill..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 12px 10px 38px',
                borderRadius: '8px',
                background: 'rgba(0,0,0,0.4)',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontFamily: 'inherit'
              }}
            />
          </div>

          {/* Difficulty Filter */}
          <div style={{ display: 'flex', gap: '6px' }}>
            {['All', 'Beginner', 'Intermediate', 'Advanced'].map(diff => (
              <button
                key={diff}
                className={selectedDifficulty === diff ? 'badge badge-beginner' : 'btn-secondary'}
                style={{ padding: '8px 12px', fontSize: '0.8rem', flex: 1, justifyContent: 'center' }}
                onClick={() => setSelectedDifficulty(diff)}
              >
                {diff}
              </button>
            ))}
          </div>

          {/* Category Filter Dropdown */}
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            style={{
              width: '100%',
              padding: '10px 12px',
              borderRadius: '8px',
              background: '#111827',
              border: '1px solid var(--border-color)',
              color: '#ffffff',
              fontFamily: 'inherit'
            }}
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Course Grid */}
      <div className="grid-3">
        {filteredCourses.map(course => {
          const diffClass = course.difficulty === 'Beginner' ? 'badge-beginner' : course.difficulty === 'Intermediate' ? 'badge-intermediate' : 'badge-advanced';
          return (
            <div
              key={course.id}
              className="glass-panel"
              style={{ padding: '20px', cursor: 'pointer', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}
              onClick={() => setSelectedCourse(course)}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                  <span style={{ fontFamily: 'monospace', fontWeight: '700', color: '#38bdf8' }}>[{course.id}]</span>
                  <span className={`badge ${diffClass}`}>{course.difficulty}</span>
                </div>

                <h3 style={{ fontSize: '1.1rem', marginBottom: '8px', color: '#ffffff' }}>{course.name}</h3>
                
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '16px', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
                  {course.description}
                </p>
              </div>

              <div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-dim)', marginBottom: '10px' }}>
                  Category: <span style={{ color: 'var(--text-main)' }}>{course.category}</span>
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: '10px', borderTop: '1px solid rgba(255,255,255,0.06)', fontSize: '0.8rem' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--text-muted)' }}>
                    <Clock size={14} color="#6366f1" /> {course.duration_hours} hrs
                  </span>
                  <span style={{ color: '#38bdf8', fontWeight: '600' }}>
                    {course.skills[0]}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Course Modal */}
      {selectedCourse && (
        <CourseModal course={selectedCourse} onClose={() => setSelectedCourse(null)} />
      )}
    </div>
  );
}
