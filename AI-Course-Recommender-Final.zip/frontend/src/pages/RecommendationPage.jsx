import React, { useState } from 'react';
import { User, Target, Award, CheckCircle2, ArrowLeft, BarChart2, Calendar } from 'lucide-react';
import MetricCards from '../components/MetricCards';
import LearningPathVisualizer from '../components/LearningPathVisualizer';
import CourseModal from '../components/CourseModal';
import { runComparison } from '../services/api';

export default function RecommendationPage({ recommendationResult, profileData, setActivePage, setComparisonResult }) {
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [evalLoading, setEvalLoading] = useState(false);

  if (!recommendationResult) {
    return (
      <div className="glass-panel" style={{ padding: '60px', textAlign: 'center' }}>
        <h3>No active recommendation found.</h3>
        <p style={{ color: 'var(--text-muted)', marginBottom: '20px' }}>Please configure your student profile to run the A* search agent.</p>
        <button className="btn-primary" onClick={() => setActivePage('profile')}>
          Go to Profile Entry
        </button>
      </div>
    );
  }

  const handleRunEvaluation = async () => {
    if (!profileData) return;
    setEvalLoading(true);
    try {
      const data = await runComparison(profileData);
      setComparisonResult(data);
      setActivePage('evaluation');
    } catch (err) {
      alert('Error running comparison: ' + err.message);
    } finally {
      setEvalLoading(false);
    }
  };

  return (
    <div>
      {/* Top Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px', flexWrap: 'wrap', gap: '16px' }}>
        <div>
          <button className="btn-secondary" onClick={() => setActivePage('profile')} style={{ marginBottom: '12px' }}>
            <ArrowLeft size={16} /> Edit Profile & Goal
          </button>
          <h1 style={{ fontSize: '2rem' }}>
            Personalized Learning Path for <span className="gradient-text">{profileData?.student_name || 'Student'}</span>
          </h1>
          <p style={{ color: 'var(--text-muted)' }}>
            Target Goal: <span style={{ color: '#38bdf8', fontWeight: '600' }}>{recommendationResult.career_title}</span>
          </p>
        </div>

        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          <button className="btn-primary" onClick={() => setActivePage('study-plan')}>
            <Calendar size={18} /> View My Study Plan
          </button>
          <button className="btn-secondary" onClick={handleRunEvaluation} disabled={evalLoading}>
            <BarChart2 size={18} />
            {evalLoading ? 'Running A* vs UCS...' : 'A* vs UCS Benchmarks'}
          </button>
        </div>
      </div>


      {/* Skill Gap Analysis Box */}
      <div className="glass-panel" style={{ padding: '24px', marginBottom: '30px' }}>
        <h3 style={{ fontSize: '1.1rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Target color="#06b6d4" size={20} />
          Skill Gap Analysis & Goal Test Summary
        </h3>

        <div className="grid-2">
          <div>
            <h4 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>Initial Acquired Skills ({recommendationResult.initial_skills.length}):</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {recommendationResult.initial_skills.length === 0 ? (
                <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)' }}>None specified</span>
              ) : (
                recommendationResult.initial_skills.map(s => (
                  <span key={s} className="badge badge-skill">{s}</span>
                ))
              )}
            </div>
          </div>

          <div>
            <h4 style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>Identified Skill Gaps to Acquire ({recommendationResult.missing_skills_before.length}):</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {recommendationResult.missing_skills_before.map(s => (
                <span key={s} className="badge" style={{ background: 'rgba(239, 68, 68, 0.15)', color: '#f87171', border: '1px solid rgba(239,68,68,0.3)' }}>
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Metric Analytics Cards */}
      <MetricCards result={recommendationResult} />

      {/* Interactive Visual Timeline */}
      <LearningPathVisualizer 
        pathSteps={recommendationResult.path_steps} 
        learningPath={recommendationResult.learning_path} 
        onSelectCourse={c => setSelectedCourse(c)}
      />

      {/* Course Detail Modal */}
      {selectedCourse && (
        <CourseModal course={selectedCourse} onClose={() => setSelectedCourse(null)} />
      )}
    </div>
  );
}
