import React, { useState, useEffect } from 'react';
import { CheckCircle2, RefreshCw, Award, ArrowRight } from 'lucide-react';
import { getCourses, updateStudentProgress, generateRecommendation } from '../services/api';

export default function ProgressPage({ profileData, onRecommendationGenerated, setActivePage }) {
  const [courses, setCourses] = useState([]);
  const [completedIds, setCompletedIds] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    getCourses().then(data => setCourses(data)).catch(console.error);
    if (profileData && profileData.current_skills) {
      // Find course IDs that match initial skills
      // or default completed list
    }
  }, [profileData]);

  const handleToggleCourse = (courseId) => {
    if (completedIds.includes(courseId)) {
      setCompletedIds(completedIds.filter(id => id !== courseId));
    } else {
      setCompletedIds([...completedIds, courseId]);
    }
  };

  const handleRecalculatePath = async () => {
    if (!profileData) {
      alert('Please configure your profile first!');
      setActivePage('profile');
      return;
    }

    setLoading(true);
    setMessage('');

    // Derive all skills acquired from manually checked courses plus profile skills
    const acquiredSkillsSet = new Set(profileData.current_skills || []);
    courses.forEach(c => {
      if (completedIds.includes(c.id)) {
        c.skills.forEach(s => acquiredSkillsSet.add(s));
      }
    });

    const updatedProfile = {
      ...profileData,
      current_skills: Array.from(acquiredSkillsSet)
    };

    try {
      const result = await generateRecommendation(updatedProfile);
      onRecommendationGenerated(result, updatedProfile);
      setMessage('Updated optimal learning path recalculated using A* Search!');
      setActivePage('recommendation');
    } catch (err) {
      alert('Failed to recalculate: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto' }}>
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>
          Learning Progress <span className="gradient-text">Tracker</span>
        </h1>
        <p style={{ color: 'var(--text-muted)' }}>
          Mark courses as completed to dynamically re-run the A* search agent from your updated state
        </p>
      </div>

      {message && (
        <div className="glass-panel" style={{ padding: '16px', borderColor: '#10b981', color: '#34d399', marginBottom: '24px' }}>
          {message}
        </div>
      )}

      <div className="glass-panel" style={{ padding: '28px', marginBottom: '24px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
          <div>
            <h3 style={{ fontSize: '1.2rem', color: '#ffffff' }}>Completed Course Checklist</h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Check any courses you have recently completed
            </p>
          </div>

          <button className="btn-primary" onClick={handleRecalculatePath} disabled={loading}>
            <RefreshCw size={16} className={loading ? 'spin' : ''} />
            Recalculate Remaining A* Path
          </button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '12px', maxH: '450px', overflowY: 'auto', paddingRight: '6px' }}>
          {courses.map(course => {
            const isCompleted = completedIds.includes(course.id);
            return (
              <div
                key={course.id}
                onClick={() => handleToggleCourse(course.id)}
                style={{
                  padding: '12px 16px',
                  borderRadius: '10px',
                  border: isCompleted ? '1px solid #10b981' : '1px solid rgba(255,255,255,0.08)',
                  background: isCompleted ? 'rgba(16, 185, 129, 0.12)' : 'rgba(0,0,0,0.2)',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  transition: 'all 0.2s ease'
                }}
              >
                <div style={{
                  width: '20px',
                  height: '20px',
                  borderRadius: '4px',
                  border: isCompleted ? 'none' : '2px solid var(--text-dim)',
                  background: isCompleted ? '#10b981' : 'transparent',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#ffffff'
                }}>
                  {isCompleted && '✓'}
                </div>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '0.85rem', color: isCompleted ? '#ffffff' : 'var(--text-main)' }}>
                    [{course.id}] {course.name}
                  </div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                    {course.duration_hours} hrs • {course.difficulty}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
