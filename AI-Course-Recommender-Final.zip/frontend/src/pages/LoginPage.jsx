import React, { useState } from 'react';
import { User, Mail, GraduationCap, Clock, Building2, Phone, ArrowRight, Compass, Sparkles } from 'lucide-react';

export default function LoginPage({ onLogin }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    courseName: '',
    courseDuration: '',
    universityName: '',
    contactNo: '',
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email ID is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.courseName.trim()) newErrors.courseName = 'Course name is required';
    if (!formData.courseDuration.trim()) newErrors.courseDuration = 'Course duration is required';
    if (!formData.universityName.trim()) newErrors.universityName = 'University name is required';
    if (!formData.contactNo.trim()) {
      newErrors.contactNo = 'Contact number is required';
    } else if (!/^[0-9+\-\s()]{7,15}$/.test(formData.contactNo)) {
      newErrors.contactNo = 'Please enter a valid contact number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      onLogin(formData);
    }
  };

  const handleFillDemo = () => {
    setFormData({
      name: 'Alex Johnson',
      email: 'alex.johnson@university.edu',
      courseName: 'B.Tech in Computer Science & Engineering',
      courseDuration: '4 Years',
      universityName: 'National Institute of Technology',
      contactNo: '+91 98765 43210',
    });
    setErrors({});
  };

  return (
    <div style={{
      minHeight: '85vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px 0'
    }}>
      <div 
        className="glass-panel" 
        style={{
          width: '100%',
          maxWidth: '680px',
          padding: '40px 45px',
          boxShadow: '0 20px 50px rgba(0, 0, 0, 0.6), 0 0 30px rgba(99, 102, 241, 0.15)',
          position: 'relative'
        }}
      >
        {/* Header with App Logo */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <div style={{
            width: '54px',
            height: '54px',
            borderRadius: '14px',
            background: 'linear-gradient(135deg, #6366f1 0%, #06b6d4 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 16px auto',
            boxShadow: '0 8px 24px rgba(99, 102, 241, 0.45)'
          }}>
            <Compass size={32} color="#ffffff" />
          </div>

          <h1 style={{ fontSize: '2rem', fontWeight: '800', marginBottom: '8px' }}>
            Student <span className="gradient-text">Portal Login</span>
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
            Enter your academic profile details to access the AI-based course recommendation system
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Row 1: Name and Email */}
          <div className="grid-2" style={{ marginBottom: '18px' }}>
            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <User size={15} color="#6366f1" /> Full Name
              </label>
              <input
                type="text"
                name="name"
                placeholder="e.g. Alex Johnson"
                value={formData.name}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  background: 'rgba(0,0,0,0.4)',
                  border: errors.name ? '1px solid #ef4444' : '1px solid var(--border-color)',
                  color: '#ffffff',
                  fontSize: '0.95rem',
                  fontFamily: 'inherit'
                }}
              />
              {errors.name && <span style={{ color: '#f87171', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>{errors.name}</span>}
            </div>

            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <Mail size={15} color="#06b6d4" /> Mail ID / Email Address
              </label>
              <input
                type="email"
                name="email"
                placeholder="e.g. student@university.edu"
                value={formData.email}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  background: 'rgba(0,0,0,0.4)',
                  border: errors.email ? '1px solid #ef4444' : '1px solid var(--border-color)',
                  color: '#ffffff',
                  fontSize: '0.95rem',
                  fontFamily: 'inherit'
                }}
              />
              {errors.email && <span style={{ color: '#f87171', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>{errors.email}</span>}
            </div>
          </div>

          {/* Row 2: Course Name and Course Duration */}
          <div className="grid-2" style={{ marginBottom: '18px' }}>
            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <GraduationCap size={15} color="#10b981" /> Course / Degree Name
              </label>
              <input
                type="text"
                name="courseName"
                placeholder="e.g. B.Tech Computer Science"
                value={formData.courseName}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  background: 'rgba(0,0,0,0.4)',
                  border: errors.courseName ? '1px solid #ef4444' : '1px solid var(--border-color)',
                  color: '#ffffff',
                  fontSize: '0.95rem',
                  fontFamily: 'inherit'
                }}
              />
              {errors.courseName && <span style={{ color: '#f87171', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>{errors.courseName}</span>}
            </div>

            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <Clock size={15} color="#f59e0b" /> Course Duration
              </label>
              <input
                type="text"
                name="courseDuration"
                placeholder="e.g. 4 Years / 8 Semesters"
                value={formData.courseDuration}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  background: 'rgba(0,0,0,0.4)',
                  border: errors.courseDuration ? '1px solid #ef4444' : '1px solid var(--border-color)',
                  color: '#ffffff',
                  fontSize: '0.95rem',
                  fontFamily: 'inherit'
                }}
              />
              {errors.courseDuration && <span style={{ color: '#f87171', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>{errors.courseDuration}</span>}
            </div>
          </div>

          {/* Row 3: University Name and Contact No */}
          <div className="grid-2" style={{ marginBottom: '28px' }}>
            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <Building2 size={15} color="#38bdf8" /> University / Institute Name
              </label>
              <input
                type="text"
                name="universityName"
                placeholder="e.g. National Institute of Technology"
                value={formData.universityName}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  background: 'rgba(0,0,0,0.4)',
                  border: errors.universityName ? '1px solid #ef4444' : '1px solid var(--border-color)',
                  color: '#ffffff',
                  fontSize: '0.95rem',
                  fontFamily: 'inherit'
                }}
              />
              {errors.universityName && <span style={{ color: '#f87171', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>{errors.universityName}</span>}
            </div>

            <div>
              <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <Phone size={15} color="#ec4899" /> Contact Number
              </label>
              <input
                type="text"
                name="contactNo"
                placeholder="e.g. +91 98765 43210"
                value={formData.contactNo}
                onChange={handleChange}
                style={{
                  width: '100%',
                  padding: '12px 14px',
                  borderRadius: '10px',
                  background: 'rgba(0,0,0,0.4)',
                  border: errors.contactNo ? '1px solid #ef4444' : '1px solid var(--border-color)',
                  color: '#ffffff',
                  fontSize: '0.95rem',
                  fontFamily: 'inherit'
                }}
              />
              {errors.contactNo && <span style={{ color: '#f87171', fontSize: '0.75rem', marginTop: '4px', display: 'block' }}>{errors.contactNo}</span>}
            </div>
          </div>

          {/* Action Buttons */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <button
              type="submit"
              className="btn-primary"
              style={{
                width: '100%',
                padding: '14px',
                justifyContent: 'center',
                fontSize: '1.05rem',
                fontWeight: '700'
              }}
            >
              Log In to Learning Portal <ArrowRight size={18} />
            </button>

            <button
              type="button"
              className="btn-secondary"
              onClick={handleFillDemo}
              style={{
                width: '100%',
                padding: '10px',
                justifyContent: 'center',
                fontSize: '0.85rem',
                color: 'var(--text-muted)'
              }}
            >
              <Sparkles size={14} color="#f59e0b" /> Fill Sample Student Info (Demo)
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
