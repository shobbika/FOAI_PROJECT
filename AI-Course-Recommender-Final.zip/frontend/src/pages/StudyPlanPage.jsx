import React, { useState, useEffect } from 'react';
import { 
  Calendar, Clock, CheckSquare, Square, CheckCircle2, Target, 
  BookOpen, Cpu, ChevronDown, ChevronUp, Sparkles, Layers, 
  Award, Zap, CalendarDays, TrendingUp, AlertCircle, ArrowRight, Loader2
} from 'lucide-react';
import { getCareers, getCourses, getStudyPlan, saveStudyPlanProgress, getStudyPlanProgress } from '../services/api';

export default function StudyPlanPage({ currentUser, profileData, setActivePage }) {
  const [careers, setCareers] = useState([]);
  const [allSkills, setAllSkills] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Configuration Form State
  const [selectedCareer, setSelectedCareer] = useState(profileData?.career_id || 'ai_engineer');
  const [selectedSkills, setSelectedSkills] = useState(profileData?.current_skills || ['Python Programming']);
  const [dailyHours, setDailyHours] = useState(2.0);
  const [availableDays, setAvailableDays] = useState(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']);
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);

  // Plan Result State
  const [planResult, setPlanResult] = useState(null);
  const [completedTaskIds, setCompletedTaskIds] = useState(new Set());
  const [isExplanationOpen, setIsExplanationOpen] = useState(true);
  const [selectedWeekFilter, setSelectedWeekFilter] = useState('All');

  const allDaysList = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  // Load initial careers & skills
  useEffect(() => {
    Promise.all([getCareers(), getCourses()])
      .then(([careerData, courseData]) => {
        setCareers(careerData);
        const skillSet = new Set();
        courseData.forEach(c => c.skills.forEach(s => skillSet.add(s)));
        setAllSkills(Array.from(skillSet).sort());
      })
      .catch(err => setError('Failed to load careers and courses data.'));
  }, []);

  // Automatically generate plan if profileData exists or on mount
  useEffect(() => {
    handleGeneratePlan();
  }, []);

  const handleDayToggle = (day) => {
    if (availableDays.includes(day)) {
      if (availableDays.length === 1) {
        alert('You must have at least one study day per week.');
        return;
      }
      setAvailableDays(availableDays.filter(d => d !== day));
    } else {
      setAvailableDays([...availableDays, day]);
    }
  };

  const handleSkillToggle = (skill) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const handleGeneratePlan = async () => {
    setLoading(true);
    setError('');

    const studentIdent = currentUser?.email || currentUser?.name || profileData?.student_name || 'guest_student';

    const reqData = {
      student_name: currentUser?.name || profileData?.student_name || 'Student',
      student_email: currentUser?.email || null,
      career_id: selectedCareer,
      current_skills: selectedSkills,
      interests: profileData?.interests || [],
      daily_study_hours: parseFloat(dailyHours),
      available_days: availableDays,
      start_date: startDate
    };

    try {
      const data = await getStudyPlan(reqData);
      setPlanResult(data);
      // Load saved completed task IDs from response or local state
      const initialCompleted = new Set(data.completed_task_ids || []);
      setCompletedTaskIds(initialCompleted);
      setSelectedWeekFilter('All');
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to generate study plan.');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleTask = async (taskId) => {
    const updated = new Set(completedTaskIds);
    if (updated.has(taskId)) {
      updated.delete(taskId);
    } else {
      updated.add(taskId);
    }
    setCompletedTaskIds(updated);

    // Save progress persistently to backend
    const studentIdent = currentUser?.email || currentUser?.name || profileData?.student_name || 'guest_student';
    try {
      await saveStudyPlanProgress(studentIdent, Array.from(updated));
    } catch (e) {
      console.error('Failed to save study plan progress to backend:', e);
    }
  };

  // Calculate overall progress
  const totalTasks = planResult?.schedule_days?.reduce((sum, d) => sum + d.tasks.length, 0) || 0;
  const completedCount = planResult?.schedule_days?.reduce((sum, d) => {
    return sum + d.tasks.filter(t => completedTaskIds.has(t.task_id)).length;
  }, 0) || 0;

  const totalCompletedHours = planResult?.schedule_days?.reduce((sum, d) => {
    return sum + d.tasks.filter(t => completedTaskIds.has(t.task_id)).reduce((tsum, t) => tsum + t.hours, 0);
  }, 0) || 0;

  const overallProgressPercent = totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  // Filter schedule days by selected week
  const filteredDays = planResult?.schedule_days?.filter(day => {
    if (selectedWeekFilter === 'All') return true;
    return day.week_number === parseInt(selectedWeekFilter);
  }) || [];

  const totalWeeksCount = planResult?.total_weeks || 1;
  const weekNumbers = Array.from({ length: totalWeeksCount }, (_, i) => i + 1);

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', paddingBottom: '60px' }}>
      {/* Page Header */}
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <span className="badge badge-beginner" style={{ marginBottom: '12px', fontSize: '0.85rem' }}>
          Personalized Timetable & Schedule Engine
        </span>
        <h1 style={{ fontSize: '2.4rem', fontWeight: '800', marginBottom: '8px' }}>
          My <span className="gradient-text">Study Plan</span>
        </h1>
        <p style={{ color: 'var(--text-muted)', maxWidth: '680px', margin: '0 auto' }}>
          Transforming your genuine A* Search learning path into an actionable, day-by-day weekly study timetable respecting your daily study capacity.
        </p>
      </div>

      {error && (
        <div className="glass-panel" style={{ padding: '16px 20px', borderColor: '#ef4444', color: '#f87171', marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      )}

      {/* Schedule Customization Control Card */}
      <div className="glass-panel" style={{ padding: '28px', marginBottom: '32px' }}>
        <h3 style={{ fontSize: '1.2rem', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Calendar color="#6366f1" size={20} /> Customize Your Study Availability
        </h3>

        <div className="grid-3" style={{ gap: '20px', marginBottom: '20px' }}>
          {/* Target Career */}
          <div>
            <label style={{ display: 'block', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
              Target Career Goal
            </label>
            <select
              value={selectedCareer}
              onChange={e => setSelectedCareer(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 12px',
                borderRadius: '8px',
                background: '#111827',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontFamily: 'inherit'
              }}
            >
              {careers.map(car => (
                <option key={car.id} value={car.id}>{car.title}</option>
              ))}
            </select>
          </div>

          {/* Daily Study Hours */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px' }}>
              <label style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Daily Study Hours</label>
              <span style={{ color: '#38bdf8', fontWeight: '700' }}>{dailyHours} hrs / day</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="8.0"
              step="0.5"
              value={dailyHours}
              onChange={e => setDailyHours(parseFloat(e.target.value))}
              style={{ width: '100%', accentColor: '#6366f1' }}
            />
          </div>

          {/* Start Date */}
          <div>
            <label style={{ display: 'block', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
              Plan Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={e => setStartDate(e.target.value)}
              style={{
                width: '100%',
                padding: '9px 12px',
                borderRadius: '8px',
                background: '#111827',
                border: '1px solid var(--border-color)',
                color: '#ffffff',
                fontFamily: 'inherit'
              }}
            />
          </div>
        </div>

        {/* Available Days Checkboxes */}
        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '10px' }}>
            Available Study Days in a Week (Never schedules more hours than your chosen days):
          </label>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
            {allDaysList.map(day => {
              const isSelected = availableDays.includes(day);
              return (
                <button
                  key={day}
                  type="button"
                  onClick={() => handleDayToggle(day)}
                  className="badge"
                  style={{
                    padding: '8px 14px',
                    borderRadius: '8px',
                    cursor: 'pointer',
                    background: isSelected ? 'rgba(99, 102, 241, 0.25)' : 'rgba(255, 255, 255, 0.05)',
                    color: isSelected ? '#a5b4fc' : 'var(--text-dim)',
                    border: isSelected ? '1px solid #6366f1' : '1px solid rgba(255, 255, 255, 0.08)'
                  }}
                >
                  {isSelected ? '✓ ' : '+ '} {day}
                </button>
              );
            })}
          </div>
        </div>

        <button
          className="btn-primary"
          onClick={handleGeneratePlan}
          disabled={loading}
          style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '1rem' }}
        >
          {loading ? (
            <>
              <Loader2 className="spin" size={18} />
              Calculating A* Path & Generating Timetable...
            </>
          ) : (
            <>
              Generate Personalized Study Plan <ArrowRight size={18} />
            </>
          )}
        </button>
      </div>

      {/* Plan Dashboard Overview Cards */}
      {planResult && planResult.success && (
        <>
          <div className="grid-4" style={{ marginBottom: '28px' }}>
            <div className="glass-panel" style={{ padding: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Total Study Hours</span>
                <Clock size={16} color="#6366f1" />
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: '800', color: '#ffffff' }}>
                {planResult.total_planned_hours} hrs
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '4px' }}>
                Across {planResult.courses_summary.length} sequential courses
              </div>
            </div>

            <div className="glass-panel" style={{ padding: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Weekly Pace</span>
                <CalendarDays size={16} color="#06b6d4" />
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: '800', color: '#ffffff' }}>
                {planResult.weekly_study_hours} hrs
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '4px' }}>
                {planResult.available_days.length} days × {planResult.daily_study_hours} hrs/day
              </div>
            </div>

            <div className="glass-panel" style={{ padding: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Target Finish Date</span>
                <Target size={16} color="#10b981" />
              </div>
              <div style={{ fontSize: '1.35rem', fontWeight: '800', color: '#34d399' }}>
                {planResult.estimated_completion_date}
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '4px' }}>
                {planResult.total_study_days} study days ({planResult.total_weeks} weeks)
              </div>
            </div>

            <div className="glass-panel" style={{ padding: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Overall Progress</span>
                <TrendingUp size={16} color="#f59e0b" />
              </div>
              <div style={{ fontSize: '1.75rem', fontWeight: '800', color: '#ffffff' }}>
                {overallProgressPercent}%
              </div>
              <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '4px' }}>
                {completedCount} of {totalTasks} tasks completed ({round(totalCompletedHours, 1)} hrs)
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="glass-panel" style={{ padding: '20px', marginBottom: '32px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '8px' }}>
              <span style={{ fontWeight: '600' }}>Study Plan Task Checklist Completion</span>
              <span style={{ color: '#38bdf8', fontWeight: '700' }}>{completedCount} / {totalTasks} Tasks ({overallProgressPercent}%)</span>
            </div>
            <div style={{ height: '12px', background: 'rgba(255,255,255,0.08)', borderRadius: '6px', overflow: 'hidden' }}>
              <div style={{
                width: `${overallProgressPercent}%`,
                height: '100%',
                background: 'linear-gradient(90deg, #6366f1 0%, #06b6d4 50%, #10b981 100%)',
                borderRadius: '6px',
                transition: 'width 0.4s ease'
              }} />
            </div>
          </div>

          {/* Collapsible Section: How A* Chose My Learning Path */}
          <div className="glass-panel" style={{ padding: '24px', marginBottom: '32px', borderLeft: '4px solid #6366f1' }}>
            <div 
              onClick={() => setIsExplanationOpen(!isExplanationOpen)} 
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Cpu size={22} color="#6366f1" />
                <div>
                  <h3 style={{ fontSize: '1.2rem', color: '#ffffff' }}>How A* Chose My Learning Path</h3>
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                    Beginner-friendly explanation of the cost function g(n), heuristic h(n), and total cost f(n)
                  </p>
                </div>
              </div>
              <button style={{ background: 'transparent', border: 'none', color: '#a5b4fc', cursor: 'pointer' }}>
                {isExplanationOpen ? <ChevronUp size={22} /> : <ChevronDown size={22} />}
              </button>
            </div>

            {isExplanationOpen && (
              <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
                {/* 3 Core Mathematical Concepts in Simple Language */}
                <div className="grid-3" style={{ gap: '16px', marginBottom: '20px' }}>
                  <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '10px' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Formula Component 1</div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: '#a5b4fc', margin: '4px 0' }}>g(n) – Cost So Far</div>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: '1.4' }}>
                      The total accumulated cost of all courses completed up to the current point.
                    </p>
                  </div>

                  <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '10px' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Formula Component 2</div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: '#38bdf8', margin: '4px 0' }}>h(n) – Estimated Remaining Cost</div>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: '1.4' }}>
                      An admissible estimate of the minimum cost still required to acquire your remaining career skills.
                    </p>
                  </div>

                  <div style={{ background: 'rgba(0,0,0,0.3)', padding: '16px', borderRadius: '10px' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', textTransform: 'uppercase' }}>Total Evaluation</div>
                    <div style={{ fontSize: '1.1rem', fontWeight: '700', color: '#34d399', margin: '4px 0' }}>f(n) = g(n) + h(n)</div>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: '1.4' }}>
                      The estimated total cost from start to goal through this path. A* always expands the lowest f(n).
                    </p>
                  </div>
                </div>

                {/* Important Clarification on Difficulty Penalty */}
                <div style={{ background: 'rgba(99, 102, 241, 0.1)', border: '1px solid rgba(99, 102, 241, 0.25)', padding: '14px 18px', borderRadius: '10px', marginBottom: '20px', fontSize: '0.85rem', lineHeight: '1.6' }}>
                  <strong style={{ color: '#ffffff' }}>Important note on Course Cost & Difficulty Penalties:</strong>
                  <br />
                  Course cost is calculated as: <code style={{ color: '#38bdf8' }}>duration_hours + difficulty_penalty</code>.
                  Difficulty penalty points (Beginner: 0 pts, Intermediate: 5 pts, Advanced: 10 pts) are <em>purely algorithm search weight points</em> used by A* to prioritize easier foundational topics earlier. They are <strong>NOT extra study hours or money</strong>. Your actual study hours are solely based on the course duration!
                </div>

                {/* Step-by-Step Table */}
                <h4 style={{ fontSize: '0.95rem', color: '#ffffff', marginBottom: '12px' }}>A* Path Step Calculations:</h4>
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem' }}>
                    <thead>
                      <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.1)', textAlign: 'left', color: 'var(--text-muted)' }}>
                        <th style={{ padding: '8px' }}>Step</th>
                        <th style={{ padding: '8px' }}>Course</th>
                        <th style={{ padding: '8px' }}>Difficulty</th>
                        <th style={{ padding: '8px' }}>Study Hours</th>
                        <th style={{ padding: '8px' }}>Penalty (pts)</th>
                        <th style={{ padding: '8px' }}>Step Cost</th>
                        <th style={{ padding: '8px' }}>g(n)</th>
                        <th style={{ padding: '8px' }}>h(n)</th>
                        <th style={{ padding: '8px' }}>f(n)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {planResult.algorithm_steps.map(step => (
                        <tr key={step.step_number} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                          <td style={{ padding: '10px 8px', fontWeight: '700', color: '#6366f1' }}>#{step.step_number}</td>
                          <td style={{ padding: '10px 8px', color: '#ffffff', fontWeight: '500' }}>
                            [{step.course_id}] {step.course_name}
                          </td>
                          <td style={{ padding: '10px 8px' }}>
                            <span className={`badge ${step.difficulty === 'Beginner' ? 'badge-beginner' : step.difficulty === 'Intermediate' ? 'badge-intermediate' : 'badge-advanced'}`} style={{ fontSize: '0.7rem' }}>
                              {step.difficulty}
                            </span>
                          </td>
                          <td style={{ padding: '10px 8px' }}>{step.duration_hours} hrs</td>
                          <td style={{ padding: '10px 8px', color: 'var(--text-dim)' }}>+{step.difficulty_penalty_points} pts</td>
                          <td style={{ padding: '10px 8px', fontWeight: '600' }}>{step.step_cost}</td>
                          <td style={{ padding: '10px 8px', color: '#a5b4fc', fontWeight: '600' }}>{step.accumulated_g_cost}</td>
                          <td style={{ padding: '10px 8px', color: '#38bdf8', fontWeight: '600' }}>{step.estimated_remaining_h}</td>
                          <td style={{ padding: '10px 8px', color: '#34d399', fontWeight: '700' }}>{step.total_f_cost}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div style={{ marginTop: '16px', fontSize: '0.85rem', color: 'var(--text-muted)', lineHeight: '1.5' }}>
                  <strong>Why this path was chosen:</strong> {planResult.why_path_chosen}
                </div>
              </div>
            )}
          </div>

          {/* Course-Wise Completion Progress Cards */}
          <div style={{ marginBottom: '32px' }}>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '16px', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <BookOpen color="#06b6d4" size={20} /> Course-Wise Progress & Estimated Completion Dates
            </h3>

            <div className="grid-2" style={{ gap: '16px' }}>
              {planResult.courses_summary.map((cs, idx) => {
                // Count tasks for cs
                const courseTasks = planResult.schedule_days.flatMap(d => d.tasks).filter(t => t.course_id === cs.course_id);
                const courseCompletedTasks = courseTasks.filter(t => completedTaskIds.has(t.task_id));
                const coursePct = courseTasks.length > 0 ? Math.round((courseCompletedTasks.length / courseTasks.length) * 100) : 0;

                return (
                  <div key={cs.course_id} className="glass-panel" style={{ padding: '20px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                      <div>
                        <span style={{ fontSize: '0.75rem', color: '#38bdf8', fontFamily: 'monospace', fontWeight: '700' }}>
                          Step {idx + 1} • [{cs.course_id}]
                        </span>
                        <h4 style={{ fontSize: '1rem', color: '#ffffff', marginTop: '2px' }}>{cs.course_name}</h4>
                      </div>
                      <span className={`badge ${cs.difficulty === 'Beginner' ? 'badge-beginner' : cs.difficulty === 'Intermediate' ? 'badge-intermediate' : 'badge-advanced'}`} style={{ fontSize: '0.7rem' }}>
                        {cs.difficulty}
                      </span>
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                      <span>Duration: {cs.duration_hours} hrs</span>
                      <span>Target Finish: <strong style={{ color: '#34d399' }}>{cs.estimated_completion_date}</strong></span>
                    </div>

                    {/* Mini Course Progress Bar */}
                    <div style={{ height: '8px', background: 'rgba(255,255,255,0.08)', borderRadius: '4px', overflow: 'hidden', marginBottom: '6px' }}>
                      <div style={{
                        width: `${coursePct}%`,
                        height: '100%',
                        background: coursePct === 100 ? '#10b981' : '#6366f1',
                        borderRadius: '4px',
                        transition: 'width 0.3s ease'
                      }} />
                    </div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                      <span>{courseCompletedTasks.length} of {courseTasks.length} tasks completed</span>
                      <span>{coursePct}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Daily & Weekly Timetable Roadmap */}
          <div style={{ marginBottom: '40px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px', flexWrap: 'wrap', gap: '12px' }}>
              <div>
                <h3 style={{ fontSize: '1.25rem', color: '#ffffff', display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <CalendarDays color="#10b981" size={20} /> Daily & Weekly Study Timetable
                </h3>
                <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                  Mark checkboxes as you study to track daily progress
                </p>
              </div>

              {/* Week Filter Buttons */}
              <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                <button
                  className={selectedWeekFilter === 'All' ? 'badge badge-beginner' : 'btn-secondary'}
                  style={{ padding: '6px 12px', fontSize: '0.75rem', cursor: 'pointer' }}
                  onClick={() => setSelectedWeekFilter('All')}
                >
                  All Weeks ({planResult.total_weeks})
                </button>
                {weekNumbers.slice(0, 8).map(w => (
                  <button
                    key={w}
                    className={selectedWeekFilter === String(w) ? 'badge badge-beginner' : 'btn-secondary'}
                    style={{ padding: '6px 12px', fontSize: '0.75rem', cursor: 'pointer' }}
                    onClick={() => setSelectedWeekFilter(String(w))}
                  >
                    Week {w}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Days */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              {filteredDays.map(day => {
                const dayCompletedTasks = day.tasks.filter(t => completedTaskIds.has(t.task_id));
                const isDayComplete = day.tasks.length > 0 && dayCompletedTasks.length === day.tasks.length;

                return (
                  <div 
                    key={day.day_number} 
                    className="glass-panel" 
                    style={{ 
                      padding: '20px', 
                      borderLeft: isDayComplete ? '4px solid #10b981' : '4px solid #06b6d4',
                      background: isDayComplete ? 'rgba(16, 185, 129, 0.05)' : 'var(--bg-card)'
                    }}
                  >
                    {/* Day Header */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px', flexWrap: 'wrap', gap: '10px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <div style={{
                          width: '36px',
                          height: '36px',
                          borderRadius: '8px',
                          background: isDayComplete ? '#10b981' : 'rgba(99, 102, 241, 0.2)',
                          color: '#ffffff',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          fontWeight: '700',
                          fontSize: '0.9rem'
                        }}>
                          {isDayComplete ? '✓' : `D${day.day_number}`}
                        </div>
                        <div>
                          <h4 style={{ fontSize: '1.05rem', color: '#ffffff' }}>
                            {day.day_of_week}, {day.date}
                          </h4>
                          <span style={{ fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                            Week {day.week_number} • {day.tasks.length} topics scheduled
                          </span>
                        </div>
                      </div>

                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <span className="badge" style={{ background: 'rgba(255,255,255,0.06)', color: '#38bdf8', fontSize: '0.8rem' }}>
                          <Clock size={13} style={{ marginRight: '4px' }} />
                          {day.daily_total_hours} hrs today
                        </span>
                      </div>
                    </div>

                    {/* Tasks list for this day */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                      {day.tasks.map(task => {
                        const isDone = completedTaskIds.has(task.task_id);
                        return (
                          <div
                            key={task.task_id}
                            onClick={() => handleToggleTask(task.task_id)}
                            style={{
                              display: 'flex',
                              alignItems: 'center',
                              justifyContent: 'space-between',
                              padding: '10px 14px',
                              borderRadius: '8px',
                              background: isDone ? 'rgba(16, 185, 129, 0.1)' : 'rgba(0,0,0,0.3)',
                              border: isDone ? '1px solid rgba(16, 185, 129, 0.3)' : '1px solid rgba(255,255,255,0.05)',
                              cursor: 'pointer',
                              transition: 'all 0.15s ease'
                            }}
                          >
                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                              <div style={{ color: isDone ? '#10b981' : 'var(--text-dim)' }}>
                                {isDone ? <CheckSquare size={18} /> : <Square size={18} />}
                              </div>
                              <div>
                                <span style={{
                                  fontSize: '0.9rem',
                                  color: isDone ? 'var(--text-dim)' : '#ffffff',
                                  textDecoration: isDone ? 'line-through' : 'none',
                                  fontWeight: isDone ? '400' : '500'
                                }}>
                                  {task.topic}
                                </span>
                                <div style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginTop: '2px' }}>
                                  Course: <span style={{ color: '#a5b4fc' }}>[{task.course_id}] {task.course_name}</span>
                                </div>
                              </div>
                            </div>

                            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                              <span className="badge" style={{
                                fontSize: '0.7rem',
                                background: task.task_type === 'Concept Learning' ? 'rgba(99, 102, 241, 0.15)' :
                                            task.task_type === 'Hands-on Practice' ? 'rgba(6, 182, 212, 0.15)' :
                                            task.task_type === 'Exercises & Revision' ? 'rgba(245, 158, 11, 0.15)' :
                                            'rgba(16, 185, 129, 0.15)',
                                color: task.task_type === 'Concept Learning' ? '#a5b4fc' :
                                       task.task_type === 'Hands-on Practice' ? '#38bdf8' :
                                       task.task_type === 'Exercises & Revision' ? '#fbbf24' :
                                       '#34d399'
                              }}>
                                {task.task_type}
                              </span>
                              <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', fontWeight: '600' }}>
                                {task.hours} hr{task.hours > 1 ? 's' : ''}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function round(num, decimals = 1) {
  const factor = Math.pow(10, decimals);
  return Math.round(num * factor) / factor;
}
