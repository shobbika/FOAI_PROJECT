import json
import os
from typing import List
from fastapi import APIRouter, HTTPException, Depends
from app.schemas import CourseSchema
from app.recommender.graph import CourseGraph, DatasetValidationError

router = APIRouter(prefix="/api/courses", tags=["Courses"])

DATA_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
COURSES_PATH = os.path.join(DATA_DIR, "courses.json")
CAREERS_PATH = os.path.join(DATA_DIR, "careers.json")

def get_graph() -> CourseGraph:
    try:
        return CourseGraph.load_from_json(COURSES_PATH, CAREERS_PATH)
    except DatasetValidationError as e:
        raise HTTPException(status_code=400, detail=f"Dataset Validation Failed: {str(e)}")

@router.get("", response_model=List[CourseSchema])
def get_all_courses(graph: CourseGraph = Depends(get_graph)):
    """Returns all courses available in the knowledge base."""
    return [
        CourseSchema(
            id=c.id,
            name=c.name,
            description=c.description,
            category=c.category,
            skills=c.skills,
            prerequisites=c.prerequisites,
            difficulty=c.difficulty,
            duration_hours=c.duration_hours,
            careers=c.careers,
            interests=c.interests
        ) for c in graph.courses
    ]

@router.get("/{course_id}", response_model=CourseSchema)
def get_course_by_id(course_id: str, graph: CourseGraph = Depends(get_graph)):
    """Returns detailed information for a single course by ID."""
    course = graph.courses_dict.get(course_id)
    if not course:
        raise HTTPException(status_code=404, detail=f"Course with ID '{course_id}' not found.")
    return CourseSchema(
        id=course.id,
        name=course.name,
        description=course.description,
        category=course.category,
        skills=course.skills,
        prerequisites=course.prerequisites,
        difficulty=course.difficulty,
        duration_hours=course.duration_hours,
        careers=course.careers,
        interests=course.interests
    )

@router.post("", response_model=CourseSchema)
def create_or_update_course(new_course: CourseSchema):
    """Admin endpoint: adds or updates a course in the authoritative JSON file and re-validates dataset."""
    if not os.path.exists(COURSES_PATH):
        raise HTTPException(status_code=500, detail="Courses dataset file missing.")

    with open(COURSES_PATH, "r", encoding="utf-8") as f:
        raw_courses = json.load(f)

    # Replace existing or append
    updated_raw = [c for c in raw_courses if c.get("id") != new_course.id]
    updated_raw.append(new_course.dict())

    # Write temporarily and attempt load validation
    with open(COURSES_PATH, "w", encoding="utf-8") as f:
        json.dump(updated_raw, f, indent=2)

    try:
        CourseGraph.load_from_json(COURSES_PATH, CAREERS_PATH)
    except DatasetValidationError as e:
        # Revert write on validation error
        with open(COURSES_PATH, "w", encoding="utf-8") as f:
            json.dump(raw_courses, f, indent=2)
        raise HTTPException(status_code=400, detail=f"Invalid Course Data: {str(e)}")

    return new_course
