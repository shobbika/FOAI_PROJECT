from typing import List
from fastapi import APIRouter, HTTPException, Depends
from app.schemas import CareerSchema
from app.recommender.graph import CourseGraph
from app.api.courses import get_graph

router = APIRouter(prefix="/api/careers", tags=["Careers"])

@router.get("", response_model=List[CareerSchema])
def get_all_careers(graph: CourseGraph = Depends(get_graph)):
    """Returns all career goals and their required skill profiles."""
    return [
        CareerSchema(
            id=car.id,
            title=car.title,
            description=car.description,
            required_skills=car.required_skills
        ) for car in graph.careers
    ]

@router.get("/{career_id}", response_model=CareerSchema)
def get_career_by_id(career_id: str, graph: CourseGraph = Depends(get_graph)):
    """Returns detailed information for a single career goal."""
    career = graph.careers_dict.get(career_id)
    if not career:
        raise HTTPException(status_code=404, detail=f"Career goal '{career_id}' not found.")
    return CareerSchema(
        id=career.id,
        title=career.title,
        description=career.description,
        required_skills=career.required_skills
    )
