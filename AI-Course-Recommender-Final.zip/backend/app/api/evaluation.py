from typing import Set, List
from fastapi import APIRouter, HTTPException, Depends
from app.schemas import RecommendationRequest, ComparisonResponse, AlgorithmMetricSchema
from app.recommender.graph import CourseGraph
from app.recommender.astar import AStarRecommender
from app.recommender.ucs import UCSRecommender
from app.api.courses import get_graph

router = APIRouter(prefix="/api/evaluation", tags=["Evaluation"])

@router.post("/compare", response_model=ComparisonResponse)
def compare_astar_and_ucs(
    req: RecommendationRequest,
    graph: CourseGraph = Depends(get_graph)
):
    """
    Academic Evaluation Endpoint:
    Runs A* Search and Uniform Cost Search (UCS / Dijkstra) on identical problem instances.
    Measures and compares node expansions, total path cost, and execution duration.
    """
    career = graph.careers_dict.get(req.career_id)
    if not career:
        raise HTTPException(status_code=404, detail=f"Career goal '{req.career_id}' not found.")

    student_skills = set(req.current_skills)
    interests = set(req.interests)

    # 1. Run A* Search
    astar_engine = AStarRecommender(graph)
    astar_res = astar_engine.recommend(student_skills, req.career_id, interests)

    # 2. Run Uniform Cost Search (UCS)
    ucs_engine = UCSRecommender(graph)
    ucs_res = ucs_engine.recommend(student_skills, req.career_id, interests)

    if not astar_res.success or not ucs_res.success:
        raise HTTPException(status_code=400, detail="Evaluation failed: search problem is invalid or goal is unreachable.")

    nodes_saved = ucs_res.nodes_expanded - astar_res.nodes_expanded
    reduction_pct = (nodes_saved / max(1, ucs_res.nodes_expanded)) * 100.0

    astar_metrics = AlgorithmMetricSchema(
        algorithm_name="A* Search",
        success=astar_res.success,
        path_length=len(astar_res.learning_path),
        total_cost=round(astar_res.total_cost, 2),
        total_duration_hours=round(astar_res.total_duration_hours, 1),
        nodes_expanded=astar_res.nodes_expanded,
        execution_time_ms=round(astar_res.execution_time_ms, 3),
        course_ids=[c.id for c in astar_res.learning_path]
    )

    ucs_metrics = AlgorithmMetricSchema(
        algorithm_name="Uniform Cost Search (Dijkstra)",
        success=ucs_res.success,
        path_length=len(ucs_res.learning_path),
        total_cost=round(ucs_res.total_cost, 2),
        total_duration_hours=round(ucs_res.total_duration_hours, 1),
        nodes_expanded=ucs_res.nodes_expanded,
        execution_time_ms=round(ucs_res.execution_time_ms, 3),
        course_ids=[c.id for c in ucs_res.learning_path]
    )

    is_cost_identical = abs(astar_res.total_cost - ucs_res.total_cost) < 1e-4

    return ComparisonResponse(
        career_id=req.career_id,
        career_title=career.title,
        initial_skills=req.current_skills,
        astar_metrics=astar_metrics,
        ucs_metrics=ucs_metrics,
        nodes_saved_by_astar=nodes_saved,
        percentage_node_reduction=round(reduction_pct, 2),
        is_path_cost_identical=is_cost_identical
    )
