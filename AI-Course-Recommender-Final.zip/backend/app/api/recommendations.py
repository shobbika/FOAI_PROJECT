from fastapi import APIRouter, HTTPException, Depends
from app.schemas import RecommendationRequest, RecommendationResponse, CourseSchema, RecommendationStepSchema
from app.recommender.graph import CourseGraph
from app.recommender.astar import AStarRecommender
from app.api.courses import get_graph

router = APIRouter(prefix="/api/recommendations", tags=["Recommendations"])

@router.post("", response_model=RecommendationResponse)
def generate_recommendation(
    req: RecommendationRequest,
    graph: CourseGraph = Depends(get_graph)
):
    """
    Core API Endpoint: Runs genuine A* state-space search to generate a personalized learning path.
    Does NOT use rules, hardcoded lists, or external recommendation APIs.
    """
    recommender = AStarRecommender(graph)
    
    student_skills = set(req.current_skills)
    interests = set(req.interests)

    result = recommender.recommend(
        student_initial_skills=student_skills,
        career_id=req.career_id,
        student_interests=interests
    )

    if not result.success:
        raise HTTPException(status_code=400, detail=result.message)

    # Convert to Response Pydantic model
    learning_path_schemas = [
        CourseSchema(
            id=c.id,
            name=c.name,
            description=c.description,
            category=c.category,
            skills=c.skills,
            prerequisites=c.prerequisites,
            difficulty=c.difficulty,
            duration_hours=c.duration_hours,
            careers=c.careers,
            interests=c.interests
        ) for c in result.learning_path
    ]

    step_schemas = [
        RecommendationStepSchema(
            course_id=s.course_id,
            course_name=s.course_name,
            duration_hours=s.duration_hours,
            difficulty=s.difficulty,
            difficulty_penalty=s.difficulty_penalty,
            step_cost=s.step_cost,
            accumulated_g=s.accumulated_g,
            heuristic_h=s.heuristic_h,
            total_f=s.total_f,
            skills_acquired=s.skills_acquired,
            prerequisites=s.prerequisites
        ) for s in result.path_steps
    ]

    available_hours = max(1.0, req.available_hours_per_week)
    estimated_weeks = round(result.total_duration_hours / available_hours, 1)

    return RecommendationResponse(
        success=True,
        message=result.message,
        career_title=result.career_title,
        initial_skills=result.initial_skills,
        acquired_skills=result.acquired_skills,
        missing_skills_before=result.missing_skills_before,
        missing_skills_after=result.missing_skills_after,
        learning_path=learning_path_schemas,
        path_steps=step_schemas,
        total_cost=result.total_cost,
        total_duration_hours=result.total_duration_hours,
        estimated_weeks=estimated_weeks,
        nodes_expanded=result.nodes_expanded,
        execution_time_ms=result.execution_time_ms
    )
