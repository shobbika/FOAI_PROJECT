import json
import datetime
from typing import List, Set
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import StudyPlanProgressModel
from app.schemas import (
    StudyPlanRequest,
    StudyPlanResponse,
    StudyPlanProgressRequest,
    StudyPlanProgressResponse,
    StudyTaskSchema,
    DayScheduleSchema,
    CourseScheduleSummarySchema,
    AlgorithmExplanationStepSchema,
)
from app.recommender.graph import CourseGraph
from app.recommender.planner import StudyPlanner
from app.api.courses import get_graph

router = APIRouter(prefix="/api/study-plan", tags=["Study Plan"])

@router.post("", response_model=StudyPlanResponse)
def generate_study_plan(
    req: StudyPlanRequest,
    graph: CourseGraph = Depends(get_graph),
    db: Session = Depends(get_db)
):
    """
    Generates a personalized daily and weekly study timetable.
    Uses genuine A* Search to calculate the exact optimal course sequence,
    then distributes course tasks across the student's available days and daily study hours.
    """
    planner = StudyPlanner(graph)
    initial_skills = set(req.current_skills)
    interests = set(req.interests)

    try:
        plan_result = planner.create_study_plan(
            student_initial_skills=initial_skills,
            career_id=req.career_id,
            daily_study_hours=req.daily_study_hours,
            available_days=req.available_days,
            start_date_str=req.start_date,
            student_interests=interests
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    if not plan_result.success:
        raise HTTPException(status_code=400, detail=plan_result.message)

    # Fetch previously saved completed task IDs if student identifier provided
    student_ident = req.student_email or req.student_name or "default_student"
    saved_progress = db.query(StudyPlanProgressModel).filter(
        StudyPlanProgressModel.student_id == student_ident
    ).first()
    completed_task_ids = json.loads(saved_progress.completed_task_ids_json) if saved_progress else []

    # Map dataclasses to Pydantic schemas
    courses_summary_schemas = [
        CourseScheduleSummarySchema(
            course_id=c.course_id,
            course_name=c.course_name,
            duration_hours=c.duration_hours,
            difficulty=c.difficulty,
            difficulty_penalty=c.difficulty_penalty,
            skills_acquired=c.skills_acquired,
            prerequisites=c.prerequisites,
            start_date=c.start_date,
            estimated_completion_date=c.estimated_completion_date,
            total_tasks_count=c.total_tasks_count
        ) for c in plan_result.courses_summary
    ]

    schedule_days_schemas = []
    for day in plan_result.schedule_days:
        task_schemas = [
            StudyTaskSchema(
                task_id=t.task_id,
                course_id=t.course_id,
                course_name=t.course_name,
                topic=t.topic,
                task_type=t.task_type,
                hours=t.hours,
                completed=(t.task_id in completed_task_ids)
            ) for t in day.tasks
        ]
        schedule_days_schemas.append(DayScheduleSchema(
            day_number=day.day_number,
            date=day.date,
            day_of_week=day.day_of_week,
            week_number=day.week_number,
            daily_total_hours=day.daily_total_hours,
            tasks=task_schemas
        ))

    algorithm_steps_schemas = [
        AlgorithmExplanationStepSchema(
            step_number=s.step_number,
            course_id=s.course_id,
            course_name=s.course_name,
            difficulty=s.difficulty,
            duration_hours=s.duration_hours,
            difficulty_penalty_points=s.difficulty_penalty_points,
            step_cost=s.step_cost,
            accumulated_g_cost=s.accumulated_g_cost,
            estimated_remaining_h=s.estimated_remaining_h,
            total_f_cost=s.total_f_cost,
            reason=s.reason
        ) for s in plan_result.algorithm_steps
    ]

    return StudyPlanResponse(
        success=True,
        message=plan_result.message,
        career_title=plan_result.career_title,
        initial_skills=plan_result.initial_skills,
        total_planned_hours=plan_result.total_planned_hours,
        daily_study_hours=plan_result.daily_study_hours,
        weekly_study_hours=plan_result.weekly_study_hours,
        available_days=plan_result.available_days,
        start_date=plan_result.start_date,
        estimated_completion_date=plan_result.estimated_completion_date,
        total_calendar_days=plan_result.total_calendar_days,
        total_study_days=plan_result.total_study_days,
        total_weeks=plan_result.total_weeks,
        courses_summary=courses_summary_schemas,
        schedule_days=schedule_days_schemas,
        algorithm_steps=algorithm_steps_schemas,
        cost_function_description=plan_result.cost_function_description,
        heuristic_description=plan_result.heuristic_description,
        why_path_chosen=plan_result.why_path_chosen,
        completed_task_ids=completed_task_ids
    )

@router.post("/progress", response_model=StudyPlanProgressResponse)
def save_study_plan_progress(
    req: StudyPlanProgressRequest,
    db: Session = Depends(get_db)
):
    """
    Saves student study plan completed task checkboxes persistently.
    """
    record = db.query(StudyPlanProgressModel).filter(
        StudyPlanProgressModel.student_id == req.student_id
    ).first()

    if not record:
        record = StudyPlanProgressModel(
            student_id=req.student_id,
            completed_task_ids_json=json.dumps(req.completed_task_ids)
        )
        db.add(record)
    else:
        record.completed_task_ids_json = json.dumps(req.completed_task_ids)

    db.commit()
    db.refresh(record)

    return StudyPlanProgressResponse(
        student_id=record.student_id,
        completed_task_ids=json.loads(record.completed_task_ids_json),
        updated_at=record.updated_at.isoformat() if record.updated_at else datetime.datetime.utcnow().isoformat()
    )

@router.get("/progress/{student_id}", response_model=StudyPlanProgressResponse)
def get_study_plan_progress(
    student_id: str,
    db: Session = Depends(get_db)
):
    """
    Fetches saved study plan task progress for a student.
    """
    record = db.query(StudyPlanProgressModel).filter(
        StudyPlanProgressModel.student_id == student_id
    ).first()

    if not record:
        return StudyPlanProgressResponse(
            student_id=student_id,
            completed_task_ids=[],
            updated_at=datetime.datetime.utcnow().isoformat()
        )

    return StudyPlanProgressResponse(
        student_id=record.student_id,
        completed_task_ids=json.loads(record.completed_task_ids_json),
        updated_at=record.updated_at.isoformat() if record.updated_at else datetime.datetime.utcnow().isoformat()
    )
