import json
import datetime
from typing import List
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import StudentProfileModel, StudentProgressModel
from app.schemas import StudentProfileRequest, StudentProfileResponse, ProgressUpdateRequest, ProgressResponse

router = APIRouter(prefix="/api/students", tags=["Students"])

@router.post("", response_model=StudentProfileResponse)
def create_student_profile(req: StudentProfileRequest, db: Session = Depends(get_db)):
    """Creates and saves a new student profile persistently in SQLite database."""
    profile = StudentProfileModel(
        name=req.name,
        knowledge_level=req.knowledge_level,
        available_hours_per_week=req.available_hours_per_week,
        current_skills_json=json.dumps(req.current_skills),
        interests_json=json.dumps(req.interests),
        selected_career_id=req.selected_career_id
    )
    db.add(profile)
    db.commit()
    db.refresh(profile)

    return StudentProfileResponse(
        id=profile.id,
        name=profile.name,
        knowledge_level=profile.knowledge_level,
        available_hours_per_week=profile.available_hours_per_week,
        current_skills=json.loads(profile.current_skills_json),
        interests=json.loads(profile.interests_json),
        selected_career_id=profile.selected_career_id
    )

@router.get("/{student_id}", response_model=StudentProfileResponse)
def get_student_profile(student_id: int, db: Session = Depends(get_db)):
    """Fetches student profile by ID."""
    profile = db.query(StudentProfileModel).filter(StudentProfileModel.id == student_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail=f"Student profile #{student_id} not found.")

    return StudentProfileResponse(
        id=profile.id,
        name=profile.name,
        knowledge_level=profile.knowledge_level,
        available_hours_per_week=profile.available_hours_per_week,
        current_skills=json.loads(profile.current_skills_json),
        interests=json.loads(profile.interests_json),
        selected_career_id=profile.selected_career_id
    )

@router.post("/progress", response_model=ProgressResponse)
def update_student_progress(req: ProgressUpdateRequest, db: Session = Depends(get_db)):
    """Updates completed courses progress persistently for a student."""
    profile = db.query(StudentProfileModel).filter(StudentProfileModel.id == req.student_id).first()
    if not profile:
        raise HTTPException(status_code=404, detail=f"Student profile #{req.student_id} not found.")

    progress = db.query(StudentProgressModel).filter(StudentProgressModel.student_id == req.student_id).first()
    if not progress:
        progress = StudentProgressModel(
            student_id=req.student_id,
            completed_course_ids_json=json.dumps(req.completed_course_ids)
        )
        db.add(progress)
    else:
        progress.completed_course_ids_json = json.dumps(req.completed_course_ids)

    db.commit()
    db.refresh(progress)

    return ProgressResponse(
        student_id=progress.student_id,
        completed_course_ids=json.loads(progress.completed_course_ids_json),
        updated_at=progress.updated_at.isoformat() if progress.updated_at else datetime.datetime.utcnow().isoformat()
    )

@router.get("/{student_id}/progress", response_model=ProgressResponse)
def get_student_progress(student_id: int, db: Session = Depends(get_db)):
    """Fetches persistent progress for a student."""
    progress = db.query(StudentProgressModel).filter(StudentProgressModel.student_id == student_id).first()
    if not progress:
        return ProgressResponse(
            student_id=student_id,
            completed_course_ids=[],
            updated_at=datetime.datetime.utcnow().isoformat()
        )
    return ProgressResponse(
        student_id=progress.student_id,
        completed_course_ids=json.loads(progress.completed_course_ids_json),
        updated_at=progress.updated_at.isoformat() if progress.updated_at else datetime.datetime.utcnow().isoformat()
    )
