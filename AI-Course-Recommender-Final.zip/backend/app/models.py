import datetime
from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from app.database import Base

class StudentProfileModel(Base):
    __tablename__ = "student_profiles"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    name = Column(String, default="Student")
    knowledge_level = Column(String, default="Beginner") # Beginner, Intermediate, Advanced
    available_hours_per_week = Column(Float, default=10.0)
    current_skills_json = Column(Text, default="[]") # JSON list of strings
    interests_json = Column(Text, default="[]") # JSON list of strings
    selected_career_id = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class StudentProgressModel(Base):
    __tablename__ = "student_progress"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    student_id = Column(Integer, index=True, nullable=False)
    completed_course_ids_json = Column(Text, default="[]") # JSON list of completed course IDs
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class StudyPlanProgressModel(Base):
    __tablename__ = "study_plan_progress"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    student_id = Column(String, index=True, nullable=False) # e.g. student email or ID
    completed_task_ids_json = Column(Text, default="[]") # JSON list of completed study plan task IDs
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

