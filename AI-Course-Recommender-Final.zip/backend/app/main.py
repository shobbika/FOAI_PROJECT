import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import engine, Base
from app.api import courses, careers, recommendations, students, evaluation, study_plan
from app.recommender.graph import CourseGraph, DatasetValidationError

# Initialize SQLite tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="AI Course Recommendation System",
    description="Personalized Course Recommendation and Learning Path System using A* Search",
    version="1.0.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Allow local React frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register API Routers
app.include_router(courses.router)
app.include_router(careers.router)
app.include_router(recommendations.router)
app.include_router(students.router)
app.include_router(evaluation.router)
app.include_router(study_plan.router)


@app.get("/api/health", tags=["Health"])
def health_check():
    """Healthcheck endpoint returning database and dataset status."""
    data_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "data"))
    courses_path = os.path.join(data_dir, "courses.json")
    careers_path = os.path.join(data_dir, "careers.json")

    dataset_valid = True
    dataset_message = "Dataset valid."
    try:
        graph = CourseGraph.load_from_json(courses_path, careers_path)
        course_count = len(graph.courses)
        career_count = len(graph.careers)
    except DatasetValidationError as e:
        dataset_valid = False
        dataset_message = f"Dataset Error: {str(e)}"
        course_count = 0
        career_count = 0

    return {
        "status": "healthy" if dataset_valid else "degraded",
        "dataset_valid": dataset_valid,
        "dataset_message": dataset_message,
        "courses_count": course_count,
        "careers_count": career_count
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
