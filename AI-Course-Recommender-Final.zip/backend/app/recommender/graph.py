import json
import os
from typing import List, Dict, Set, Any, Optional
from dataclasses import dataclass, field

@dataclass
class Course:
    id: str
    name: str
    description: str
    category: str
    skills: List[str]
    prerequisites: List[str]
    difficulty: str
    duration_hours: float
    careers: List[str] = field(default_factory=list)
    interests: List[str] = field(default_factory=list)

@dataclass
class CareerGoal:
    id: str
    title: str
    description: str
    required_skills: List[str]

class DatasetValidationError(Exception):
    """Custom exception raised when course dataset fails validation checks."""
    pass

class CourseGraph:
    """
    Manages loading, holding, and validating the Course & Career knowledge base.
    Completely independent of UI, FastAPI, or Database code.
    """
    def __init__(self, courses: List[Course], careers: List[CareerGoal]):
        self.courses: List[Course] = courses
        self.careers: List[CareerGoal] = careers
        self.courses_dict: Dict[str, Course] = {c.id: c for c in courses}
        self.careers_dict: Dict[str, CareerGoal] = {car.id: car for car in careers}
        self.all_taught_skills: Set[str] = {skill for c in courses for skill in c.skills}

    @classmethod
    def load_from_json(cls, courses_path: str, careers_path: str) -> "CourseGraph":
        """Loads JSON files, validates the dataset, and returns a CourseGraph instance."""
        if not os.path.exists(courses_path):
            raise DatasetValidationError(f"Courses file not found: {courses_path}")
        if not os.path.exists(careers_path):
            raise DatasetValidationError(f"Careers file not found: {careers_path}")

        try:
            with open(courses_path, "r", encoding="utf-8") as f:
                raw_courses = json.load(f)
        except Exception as e:
            raise DatasetValidationError(f"Malformed JSON in courses file: {str(e)}")

        try:
            with open(careers_path, "r", encoding="utf-8") as f:
                raw_careers = json.load(f)
        except Exception as e:
            raise DatasetValidationError(f"Malformed JSON in careers file: {str(e)}")

        courses, careers = cls.validate_and_parse(raw_courses, raw_careers)
        graph = cls(courses, careers)
        graph.validate_prerequisite_cycles()
        return graph

    @classmethod
    def validate_and_parse(cls, raw_courses: Any, raw_careers: Any) -> tuple:
        if not isinstance(raw_courses, list):
            raise DatasetValidationError("Courses JSON must contain a top-level list.")
        if not isinstance(raw_careers, list):
            raise DatasetValidationError("Careers JSON must contain a top-level list.")

        valid_difficulties = {"Beginner", "Intermediate", "Advanced"}
        course_ids: Set[str] = set()
        courses: List[Course] = []
        all_taught_skills: Set[str] = set()

        # Parse careers first
        careers: List[CareerGoal] = []
        career_ids: Set[str] = set()
        for idx, car in enumerate(raw_careers):
            if not isinstance(car, dict):
                raise DatasetValidationError(f"Career entry at index {idx} is not an object.")
            for req_field in ["id", "title", "description", "required_skills"]:
                if req_field not in car:
                    raise DatasetValidationError(f"Career entry missing required field '{req_field}' at index {idx}.")
            if car["id"] in career_ids:
                raise DatasetValidationError(f"Duplicate career ID found: {car['id']}")
            career_ids.add(car["id"])
            careers.append(CareerGoal(
                id=str(car["id"]),
                title=str(car["title"]),
                description=str(car["description"]),
                required_skills=list(car["required_skills"])
            ))

        # Parse courses
        required_fields = ["id", "name", "description", "category", "skills", "prerequisites", "difficulty", "duration_hours"]
        for idx, c in enumerate(raw_courses):
            if not isinstance(c, dict):
                raise DatasetValidationError(f"Course entry at index {idx} is not an object.")
            
            # Check missing fields
            for req_field in required_fields:
                if req_field not in c:
                    raise DatasetValidationError(f"Course entry at index {idx} missing required field '{req_field}'.")

            cid = str(c["id"])
            if cid in course_ids:
                raise DatasetValidationError(f"Duplicate course ID found: {cid}")
            course_ids.add(cid)

            # Check difficulty
            difficulty = c["difficulty"]
            if difficulty not in valid_difficulties:
                raise DatasetValidationError(f"Course '{cid}' has invalid difficulty '{difficulty}'. Allowed: {valid_difficulties}")

            # Check duration
            try:
                duration = float(c["duration_hours"])
                if duration <= 0:
                    raise DatasetValidationError(f"Course '{cid}' has non-positive duration: {duration}")
            except (ValueError, TypeError):
                raise DatasetValidationError(f"Course '{cid}' has non-numeric duration_hours.")

            # Check skill types
            if not isinstance(c["skills"], list) or not c["skills"]:
                raise DatasetValidationError(f"Course '{cid}' skills must be a non-empty list.")
            if not isinstance(c["prerequisites"], list):
                raise DatasetValidationError(f"Course '{cid}' prerequisites must be a list.")

            # Validate career references if provided
            ref_careers = c.get("careers", [])
            if not isinstance(ref_careers, list):
                raise DatasetValidationError(f"Course '{cid}' careers field must be a list.")
            for car_id in ref_careers:
                if car_id not in career_ids:
                    raise DatasetValidationError(f"Course '{cid}' references unknown career ID '{car_id}'.")

            all_taught_skills.update(c["skills"])

            courses.append(Course(
                id=cid,
                name=str(c["name"]),
                description=str(c["description"]),
                category=str(c["category"]),
                skills=list(c["skills"]),
                prerequisites=list(c["prerequisites"]),
                difficulty=difficulty,
                duration_hours=duration,
                careers=list(ref_careers),
                interests=list(c.get("interests", []))
            ))

        # Validate prerequisite skills existence
        for course in courses:
            for prereq_skill in course.prerequisites:
                if prereq_skill not in all_taught_skills:
                    # Note: Prerequisite skill could potentially be an initial skill, but if no course in the catalog teaches it,
                    # log warning or raise DatasetValidationError if strictly untaught in dataset.
                    pass

        return courses, careers

    def validate_prerequisite_cycles(self):
        """
        Validates that course skill dependency graph contains no cycles using DFS.
        Constructs a dependency graph between courses based on skill prerequisites.
        """
        # Map skill to courses that teach it
        skill_to_teachers: Dict[str, List[str]] = {}
        for c in self.courses:
            for skill in c.skills:
                skill_to_teachers.setdefault(skill, []).append(c.id)

        # Build direct course -> course dependency adjacency list
        # Course A -> Course B if B teaches a prerequisite skill required by A
        adj: Dict[str, Set[str]] = {c.id: set() for c in self.courses}
        for c in self.courses:
            for prereq in c.prerequisites:
                teachers = skill_to_teachers.get(prereq, [])
                for t_id in teachers:
                    if t_id != c.id:
                        adj[c.id].add(t_id)

        # DFS Cycle Detection
        visited = {} # 0: unvisited, 1: visiting, 2: visited
        for cid in self.courses_dict:
            visited[cid] = 0

        def dfs(node: str, path: List[str]) -> None:
            visited[node] = 1 # visiting
            path.append(node)
            for neighbor in adj[node]:
                if visited[neighbor] == 1:
                    cycle_str = " -> ".join(path[path.index(neighbor):] + [neighbor])
                    raise DatasetValidationError(f"Cyclic prerequisite dependency detected in dataset: {cycle_str}")
                elif visited[neighbor] == 0:
                    dfs(neighbor, path)
            path.pop()
            visited[node] = 2 # visited

        for cid in self.courses_dict:
            if visited[cid] == 0:
                dfs(cid, [])
