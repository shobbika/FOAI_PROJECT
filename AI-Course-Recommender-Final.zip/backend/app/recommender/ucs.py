import heapq
import time
from typing import Set, Dict, List, Any, Optional

from app.recommender.state import State
from app.recommender.cost import calculate_course_cost
from app.recommender.graph import CourseGraph
from app.recommender.astar import RecommendationResult, RecommendationStep

class UCSRecommender:
    """
    Uniform Cost Search (Dijkstra's Algorithm) Engine.
    Uses f(n) = g(n) where h(n) = 0 for all states.
    Uses identical state representation, successor logic, and cost function as A* Search.
    """
    def __init__(self, graph: CourseGraph):
        self.graph = graph

    def recommend(
        self,
        student_initial_skills: Set[str],
        career_id: str,
        student_interests: Optional[Set[str]] = None
    ) -> RecommendationResult:
        start_time = time.perf_counter()
        
        if student_interests is None:
            student_interests = set()

        career = self.graph.careers_dict.get(career_id)
        if not career:
            return RecommendationResult(
                success=False,
                message=f"Career goal '{career_id}' not found in database.",
                career_title="Unknown",
                initial_skills=list(student_initial_skills),
                acquired_skills=list(student_initial_skills),
                missing_skills_before=[],
                missing_skills_after=[],
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=0,
                execution_time_ms=(time.perf_counter() - start_time) * 1000.0
            )

        required_skills = set(career.required_skills)
        initial_skills = set(student_initial_skills)
        missing_skills_before = list(required_skills - initial_skills)

        start_state = State(completed_courses=frozenset())
        initial_acquired = start_state.get_acquired_skills(initial_skills, self.graph.courses_dict)

        if required_skills.issubset(initial_acquired):
            return RecommendationResult(
                success=True,
                message="Student already possesses all skills required for this career goal.",
                career_title=career.title,
                initial_skills=list(initial_skills),
                acquired_skills=list(initial_acquired),
                missing_skills_before=missing_skills_before,
                missing_skills_after=[],
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=0,
                execution_time_ms=(time.perf_counter() - start_time) * 1000.0
            )

        # Priority Queue storing tuples: (g_score, tie_breaker, state, path_course_ids)
        counter = 0
        open_set = []
        heapq.heappush(open_set, (0.0, 0, 0.0, counter, start_state, []))

        g_scores: Dict[State, float] = {start_state: 0.0}
        nodes_expanded = 0

        final_path_ids: Optional[List[str]] = None
        final_g_score: float = 0.0

        while open_set:
            g, tie_breaker, _, _, current_state, path = heapq.heappop(open_set)
            nodes_expanded += 1

            if g > g_scores.get(current_state, float('inf')):
                continue

            current_acquired = current_state.get_acquired_skills(initial_skills, self.graph.courses_dict)

            # Goal Test
            if required_skills.issubset(current_acquired):
                final_path_ids = path
                final_g_score = g
                break

            # Successor Function
            for course in self.graph.courses:
                if course.id in current_state.completed_courses:
                    continue

                prereqs_met = all(p in current_acquired for p in course.prerequisites)
                if not prereqs_met:
                    continue

                course_skills_set = set(course.skills)
                if not (course_skills_set - current_acquired):
                    continue

                step_cost = calculate_course_cost(course)
                tentative_g = g + step_cost
                next_completed = current_state.completed_courses | {course.id}
                next_state = State(next_completed)

                if tentative_g < g_scores.get(next_state, float('inf')):
                    g_scores[next_state] = tentative_g
                    interest_match = sum(1 for tag in course.interests if tag in student_interests)
                    counter += 1
                    heapq.heappush(open_set, (tentative_g, -interest_match, tentative_g, counter, next_state, path + [course.id]))


        execution_time_ms = (time.perf_counter() - start_time) * 1000.0

        if final_path_ids is None:
            return RecommendationResult(
                success=False,
                message="Goal unreachable using Uniform Cost Search.",
                career_title=career.title,
                initial_skills=list(initial_skills),
                acquired_skills=list(initial_acquired),
                missing_skills_before=missing_skills_before,
                missing_skills_after=missing_skills_before,
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=nodes_expanded,
                execution_time_ms=execution_time_ms
            )

        learning_path = [self.graph.courses_dict[cid] for cid in final_path_ids]
        path_steps = []
        accumulated_g = 0.0
        total_duration = 0.0
        temp_state = State(completed_courses=frozenset())

        for cid in final_path_ids:
            c = self.graph.courses_dict[cid]
            c_cost = calculate_course_cost(c)
            accumulated_g += c_cost
            total_duration += c.duration_hours
            temp_state = State(temp_state.completed_courses | {cid})

            path_steps.append(RecommendationStep(
                course_id=c.id,
                course_name=c.name,
                duration_hours=c.duration_hours,
                difficulty=c.difficulty,
                difficulty_penalty=c_cost - c.duration_hours,
                step_cost=c_cost,
                accumulated_g=accumulated_g,
                heuristic_h=0.0, # h=0 in UCS
                total_f=accumulated_g,
                skills_acquired=c.skills,
                prerequisites=c.prerequisites
            ))

        final_acquired = temp_state.get_acquired_skills(initial_skills, self.graph.courses_dict)
        missing_skills_after = list(required_skills - final_acquired)

        return RecommendationResult(
            success=True,
            message="Path generated using Uniform Cost Search (UCS).",
            career_title=career.title,
            initial_skills=list(initial_skills),
            acquired_skills=list(final_acquired),
            missing_skills_before=missing_skills_before,
            missing_skills_after=missing_skills_after,
            learning_path=learning_path,
            path_steps=path_steps,
            total_cost=final_g_score,
            total_duration_hours=total_duration,
            nodes_expanded=nodes_expanded,
            execution_time_ms=execution_time_ms
        )
