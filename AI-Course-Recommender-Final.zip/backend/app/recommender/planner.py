import datetime
from typing import List, Dict, Set, Any, Optional
from dataclasses import dataclass, field
from copy import deepcopy

from app.recommender.graph import CourseGraph, Course, CareerGoal
from app.recommender.astar import AStarRecommender, RecommendationResult, RecommendationStep
from app.recommender.cost import calculate_course_cost, DIFFICULTY_PENALTY

@dataclass
class StudyTask:
    task_id: str
    course_id: str
    course_name: str
    topic: str
    task_type: str  # Concept Learning, Practical Practice, Exercises & Revision, Mini-Project
    hours: float
    completed: bool = False

@dataclass
class DaySchedule:
    day_number: int
    date: str
    day_of_week: str
    week_number: int
    daily_total_hours: float
    tasks: List[StudyTask]

@dataclass
class CourseScheduleSummary:
    course_id: str
    course_name: str
    duration_hours: float
    difficulty: str
    difficulty_penalty: float
    skills_acquired: List[str]
    prerequisites: List[str]
    start_date: Optional[str]
    estimated_completion_date: Optional[str]
    total_tasks_count: int

@dataclass
class AlgorithmExplanationStep:
    step_number: int
    course_id: str
    course_name: str
    difficulty: str
    duration_hours: float
    difficulty_penalty_points: float
    step_cost: float
    accumulated_g_cost: float
    estimated_remaining_h: float
    total_f_cost: float
    reason: str

@dataclass
class TimetableResult:
    success: bool
    message: str
    career_title: str
    initial_skills: List[str]
    total_planned_hours: float
    daily_study_hours: float
    weekly_study_hours: float
    available_days: List[str]
    start_date: str
    estimated_completion_date: str
    total_calendar_days: int
    total_study_days: int
    total_weeks: int
    courses_summary: List[CourseScheduleSummary]
    schedule_days: List[DaySchedule]
    algorithm_steps: List[AlgorithmExplanationStep]
    cost_function_description: str
    heuristic_description: str
    why_path_chosen: str

class StudyPlanner:
    """
    Transforms an optimal course sequence calculated by genuine A* Search
    into a personalized, day-by-day weekly study timetable.
    """
    def __init__(self, graph: CourseGraph):
        self.graph = graph
        self.recommender = AStarRecommender(graph)

    def generate_course_tasks(self, course: Course) -> List[StudyTask]:
        """
        Breaks down a course into modular study tasks matching the course's exact duration_hours.
        Tasks cover:
        1. Concept Learning & Fundamentals (approx 35%)
        2. Hands-on Practice & Coding (approx 35%)
        3. Exercises & Revision (approx 15%)
        4. Mini-Project & Assessment (approx 15%)
        """
        total_hours = float(course.duration_hours)
        skills_str = ", ".join(course.skills) if course.skills else course.name
        primary_skill = course.skills[0] if course.skills else course.name

        # Determine task chunk size (1.0 hour chunks, with remainder in last chunk)
        chunk_size = 1.0
        num_full_chunks = int(total_hours // chunk_size)
        remainder = round(total_hours % chunk_size, 2)

        raw_chunks: List[float] = [chunk_size] * num_full_chunks
        if remainder > 0:
            raw_chunks.append(remainder)
        elif not raw_chunks:
            raw_chunks = [total_hours]

        total_chunks = len(raw_chunks)
        tasks: List[StudyTask] = []

        # Define topic templates for stages
        for idx, task_hours in enumerate(raw_chunks):
            ratio = (idx + 1) / total_chunks
            task_id = f"task-{course.id}-{idx + 1}"

            if ratio <= 0.35:
                task_type = "Concept Learning"
                if idx == 0:
                    topic = f"{primary_skill}: Overview, Architecture & Core Foundations"
                elif idx == 1:
                    topic = f"{primary_skill}: Syntax, Structures & Key Principles"
                else:
                    topic = f"{primary_skill}: In-Depth Theoretical Frameworks & Analysis"
            elif ratio <= 0.70:
                task_type = "Hands-on Practice"
                if idx == int(total_chunks * 0.35):
                    topic = f"Coding Lab: Basic Implementation in {primary_skill}"
                elif idx == int(total_chunks * 0.50):
                    topic = f"Applied Workflows: Intermediate Techniques in {primary_skill}"
                else:
                    topic = f"Practical Building: Constructing Real-World Components ({skills_str})"
            elif ratio <= 0.85:
                task_type = "Exercises & Revision"
                if idx == int(total_chunks * 0.70):
                    topic = f"Problem Solving: Debugging & Practice Drills for {primary_skill}"
                else:
                    topic = f"Comprehensive Review & Knowledge Check: {course.name}"
            else:
                task_type = "Mini-Project"
                if idx == total_chunks - 1:
                    topic = f"Final Capstone Evaluation & Mini-Project Showcase: {course.name}"
                else:
                    topic = f"Hands-on Mini-Project Development for {primary_skill}"

            tasks.append(StudyTask(
                task_id=task_id,
                course_id=course.id,
                course_name=course.name,
                topic=topic,
                task_type=task_type,
                hours=task_hours,
                completed=False
            ))

        return tasks

    def create_study_plan(
        self,
        student_initial_skills: Set[str],
        career_id: str,
        daily_study_hours: float = 2.0,
        available_days: Optional[List[str]] = None,
        start_date_str: Optional[str] = None,
        student_interests: Optional[Set[str]] = None
    ) -> TimetableResult:
        """
        Executes A* Search to find the optimal course sequence, then builds
        a day-by-day timetable respecting daily hour limits and available days.
        """
        # Validate inputs
        if daily_study_hours <= 0:
            raise ValueError("Daily study hours must be greater than 0.")
        if daily_study_hours > 16.0:
            raise ValueError("Daily study hours cannot exceed 16 hours.")

        valid_day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        if available_days is not None and len(available_days) == 0:
            raise ValueError("At least one valid available study day must be selected (Monday to Sunday).")
        if available_days is None:
            available_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

        normalized_days = [d.capitalize() for d in available_days if d.capitalize() in valid_day_names]
        if not normalized_days:
            raise ValueError("At least one valid available study day must be selected (Monday to Sunday).")


        # Parse start date
        if start_date_str:
            try:
                start_date = datetime.date.fromisoformat(start_date_str)
            except ValueError:
                start_date = datetime.date.today()
        else:
            start_date = datetime.date.today()

        # 1. Run A* Search to obtain the genuine optimal course sequence
        astar_res = self.recommender.recommend(
            student_initial_skills=student_initial_skills,
            career_id=career_id,
            student_interests=student_interests
        )

        if not astar_res.success:
            return TimetableResult(
                success=False,
                message=f"Could not generate study plan: {astar_res.message}",
                career_title=astar_res.career_title,
                initial_skills=list(student_initial_skills),
                total_planned_hours=0.0,
                daily_study_hours=daily_study_hours,
                weekly_study_hours=0.0,
                available_days=normalized_days,
                start_date=start_date.isoformat(),
                estimated_completion_date=start_date.isoformat(),
                total_calendar_days=0,
                total_study_days=0,
                total_weeks=0,
                courses_summary=[],
                schedule_days=[],
                algorithm_steps=[],
                cost_function_description="",
                heuristic_description="",
                why_path_chosen=""
            )

        # If student already has all career skills
        if not astar_res.learning_path:
            return TimetableResult(
                success=True,
                message="You already possess all required skills for this career goal! No additional courses are required.",
                career_title=astar_res.career_title,
                initial_skills=list(student_initial_skills),
                total_planned_hours=0.0,
                daily_study_hours=daily_study_hours,
                weekly_study_hours=0.0,
                available_days=normalized_days,
                start_date=start_date.isoformat(),
                estimated_completion_date=start_date.isoformat(),
                total_calendar_days=0,
                total_study_days=0,
                total_weeks=0,
                courses_summary=[],
                schedule_days=[],
                algorithm_steps=[],
                cost_function_description="Course cost = Duration (hours) + Difficulty Penalty points.",
                heuristic_description="h(n) = 0 because all career skills are already satisfied.",
                why_path_chosen="Your existing skill profile fully satisfies all prerequisites and career competencies."
            )

        # 2. Convert course path into tasks in strict prerequisite order
        # Queue of all tasks across courses in A* topological sequence
        pending_tasks: List[StudyTask] = []
        course_task_counts: Dict[str, int] = {}

        for course in astar_res.learning_path:
            tasks = self.generate_course_tasks(course)
            course_task_counts[course.id] = len(tasks)
            pending_tasks.extend(tasks)

        # 3. Schedule tasks day by day
        schedule_days: List[DaySchedule] = []
        course_start_dates: Dict[str, str] = {}
        course_completion_dates: Dict[str, str] = {}
        course_scheduled_tasks: Dict[str, int] = {c.id: 0 for c in astar_res.learning_path}

        current_date = start_date
        total_tasks_to_schedule = len(pending_tasks)
        task_queue = list(pending_tasks)

        day_index = 0
        calendar_days_count = 0

        # Safety loop limit to avoid infinite loops
        max_calendar_days = 365 * 5  # up to 5 years

        while task_queue and calendar_days_count < max_calendar_days:
            day_name = current_date.strftime("%A")
            calendar_days_count += 1

            # Check if current day of week is an available study day
            if day_name in normalized_days:
                day_index += 1
                available_today = daily_study_hours
                day_tasks: List[StudyTask] = []

                while task_queue and available_today > 1e-4:
                    current_task = task_queue[0]
                    c_id = current_task.course_id

                    # Record course start date on first task of that course
                    if c_id not in course_start_dates:
                        course_start_dates[c_id] = current_date.isoformat()

                    if current_task.hours <= available_today + 1e-4:
                        # Task fits completely today
                        day_tasks.append(current_task)
                        available_today -= current_task.hours
                        task_queue.pop(0)
                        course_scheduled_tasks[c_id] += 1

                        # If all tasks of this course are scheduled, mark completion date
                        if course_scheduled_tasks[c_id] >= course_task_counts[c_id]:
                            course_completion_dates[c_id] = current_date.isoformat()
                            # Ensure clean milestone separation: dependent courses start on the next available study day
                            if task_queue and task_queue[0].course_id != c_id:
                                available_today = 0.0

                    else:
                        # Task needs to be split across days
                        allocated_hours = round(available_today, 2)
                        remaining_hours = round(current_task.hours - allocated_hours, 2)

                        # Create part 1 for today
                        part1_task = StudyTask(
                            task_id=f"{current_task.task_id}-p1",
                            course_id=current_task.course_id,
                            course_name=current_task.course_name,
                            topic=f"{current_task.topic} (Part 1)",
                            task_type=current_task.task_type,
                            hours=allocated_hours,
                            completed=False
                        )
                        day_tasks.append(part1_task)
                        available_today = 0.0

                        # Update the remaining part for the next study day
                        current_task.task_id = f"{current_task.task_id}-p2"
                        current_task.topic = f"{current_task.topic} (Part 2)"
                        current_task.hours = remaining_hours

                if day_tasks:
                    daily_total = round(sum(t.hours for t in day_tasks), 2)
                    week_num = ((current_date - start_date).days // 7) + 1
                    schedule_days.append(DaySchedule(
                        day_number=day_index,
                        date=current_date.isoformat(),
                        day_of_week=day_name,
                        week_number=week_num,
                        daily_total_hours=daily_total,
                        tasks=day_tasks
                    ))

            current_date += datetime.timedelta(days=1)

        final_completion_date = schedule_days[-1].date if schedule_days else start_date.isoformat()
        total_calendar_days = (datetime.date.fromisoformat(final_completion_date) - start_date).days + 1
        total_weeks = max(1, (total_calendar_days + 6) // 7)
        weekly_study_hours = round(len(normalized_days) * daily_study_hours, 1)

        # 4. Course Summary
        courses_summary: List[CourseScheduleSummary] = []
        for step in astar_res.path_steps:
            c = self.graph.courses_dict[step.course_id]
            courses_summary.append(CourseScheduleSummary(
                course_id=c.id,
                course_name=c.name,
                duration_hours=c.duration_hours,
                difficulty=c.difficulty,
                difficulty_penalty=step.difficulty_penalty,
                skills_acquired=c.skills,
                prerequisites=c.prerequisites,
                start_date=course_start_dates.get(c.id, start_date.isoformat()),
                estimated_completion_date=course_completion_dates.get(c.id, final_completion_date),
                total_tasks_count=course_task_counts.get(c.id, 0)
            ))

        # 5. Algorithm Explanation in plain language
        algorithm_steps: List[AlgorithmExplanationStep] = []
        for idx, s in enumerate(astar_res.path_steps):
            if s.prerequisites:
                reason = f"Selected step {idx+1}: satisfies prerequisite for advanced courses and teaches {', '.join(s.skills_acquired)} with minimal total estimated cost f(n)={s.total_f}."
            else:
                reason = f"Selected step {idx+1}: foundational entry course teaching {', '.join(s.skills_acquired)} with zero prerequisite barrier."

            algorithm_steps.append(AlgorithmExplanationStep(
                step_number=idx + 1,
                course_id=s.course_id,
                course_name=s.course_name,
                difficulty=s.difficulty,
                duration_hours=s.duration_hours,
                difficulty_penalty_points=s.difficulty_penalty,
                step_cost=s.step_cost,
                accumulated_g_cost=s.accumulated_g,
                estimated_remaining_h=s.heuristic_h,
                total_f_cost=s.total_f,
                reason=reason
            ))

        cost_explanation = (
            "Course cost = Learning Duration (hours) + Difficulty Penalty points. "
            "Difficulty Penalty points (Beginner: 0 pts, Intermediate: 5 pts, Advanced: 10 pts) "
            "are algorithm search weight points used by A* to prefer easier foundational courses early on. "
            "They are NOT extra study hours or fees."
        )

        heuristic_explanation = (
            "Heuristic h(n) estimates the minimum remaining cost needed to acquire all missing career skills. "
            "It computes the cheapest single course required for any missing skill. Because any complete solution "
            "must complete at least one course for each missing skill, h(n) never overestimates the true remaining "
            "cost (admissible), guaranteeing an optimal sequence."
        )

        why_path = (
            f"A* Search explored {astar_res.nodes_expanded} state combinations and selected this exact {len(astar_res.learning_path)}-course "
            f"sequence because it satisfies every prerequisite constraint in the correct order, avoids reteaching skills you already possess, "
            f"and achieves the lowest overall cost score (f={astar_res.total_cost}) among all possible learning pathways."
        )

        return TimetableResult(
            success=True,
            message="Personalized study timetable generated successfully based on A* course sequence.",
            career_title=astar_res.career_title,
            initial_skills=list(student_initial_skills),
            total_planned_hours=astar_res.total_duration_hours,
            daily_study_hours=daily_study_hours,
            weekly_study_hours=weekly_study_hours,
            available_days=normalized_days,
            start_date=start_date.isoformat(),
            estimated_completion_date=final_completion_date,
            total_calendar_days=total_calendar_days,
            total_study_days=len(schedule_days),
            total_weeks=total_weeks,
            courses_summary=courses_summary,
            schedule_days=schedule_days,
            algorithm_steps=algorithm_steps,
            cost_function_description=cost_explanation,
            heuristic_description=heuristic_explanation,
            why_path_chosen=why_path
        )
