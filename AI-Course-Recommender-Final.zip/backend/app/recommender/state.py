from typing import FrozenSet, Set, Dict, Any

class State:
    """
    Represents a state in the search space.
    The primary state representation is the set of completed course IDs.
    Acquired skills are dynamically derived from the student's initial skills
    plus skills taught by all completed courses.
    """
    def __init__(self, completed_courses: FrozenSet[str]):
        self.completed_courses: FrozenSet[str] = frozenset(completed_courses)

    def get_acquired_skills(self, initial_skills: Set[str], courses_dict: Dict[str, Any]) -> FrozenSet[str]:
        """
        Derives all acquired skills from initial student skills and completed courses.
        """
        acquired = set(initial_skills)
        for cid in self.completed_courses:
            course = courses_dict.get(cid)
            if course:
                acquired.update(course.skills)
        return frozenset(acquired)

    def __hash__(self) -> int:
        return hash(self.completed_courses)

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, State):
            return False
        return self.completed_courses == other.completed_courses

    def __lt__(self, other: Any) -> bool:
        if not isinstance(other, State):
            return NotImplemented
        return sorted(self.completed_courses) < sorted(other.completed_courses)

    def __repr__(self) -> str:
        return f"State(completed_courses={list(self.completed_courses)})"

