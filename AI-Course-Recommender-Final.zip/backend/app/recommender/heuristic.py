from typing import Set, Dict, Any, List
from app.recommender.state import State
from app.recommender.cost import calculate_course_cost

class HeuristicCalculator:
    """
    Computes an admissible heuristic h(n) for state-space A* search.
    h(n) estimates the lower bound of remaining course cost needed to acquire all missing career skills.
    """
    def __init__(self, courses: List[Any]):
        self.courses = courses
        # Precompute the minimum course cost for each skill taught in the catalog
        self.skill_min_cost: Dict[str, float] = {}
        for course in courses:
            cost = calculate_course_cost(course)
            for skill in course.skills:
                if skill not in self.skill_min_cost or cost < self.skill_min_cost[skill]:
                    self.skill_min_cost[skill] = cost

    def calculate(self, state: State, initial_skills: Set[str], required_skills: Set[str], courses_dict: Dict[str, Any]) -> float:
        """
        Calculates h(State).
        1. Identify missing skills: M = required_skills - acquired_skills(State)
        2. If M is empty, h(State) = 0.
        3. Else, h(State) = max_{s in M} (min_cost(s))
        
        Admissibility Guarantee:
        Since at least one course must be completed to acquire any missing skill s,
        the remaining cost to achieve the goal must be at least min_cost(s) for any s in M.
        Therefore, max_{s in M} min_cost(s) <= h*(State), guaranteeing admissibility.
        """
        acquired_skills = state.get_acquired_skills(initial_skills, courses_dict)
        missing_skills = required_skills - acquired_skills
        
        if not missing_skills:
            return 0.0
            
        max_min_cost = 0.0
        for skill in missing_skills:
            # If a skill cannot be taught by any course in dataset, return infinity (unreachable)
            cost = self.skill_min_cost.get(skill, float('inf'))
            if cost > max_min_cost:
                max_min_cost = cost
                
        return max_min_cost
