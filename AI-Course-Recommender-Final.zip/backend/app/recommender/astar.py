import heapq
import time
from typing import Set, Dict, List, Any, Optional
from dataclasses import dataclass, field

from app.recommender.state import State
from app.recommender.cost import calculate_course_cost
from app.recommender.heuristic import HeuristicCalculator
from app.recommender.graph import CourseGraph, Course, CareerGoal

@dataclass
class RecommendationStep:
    course_id: str
    course_name: str
    duration_hours: float
    difficulty: str
    difficulty_penalty: float
    step_cost: float
    accumulated_g: float
    heuristic_h: float
    total_f: float
    skills_acquired: List[str]
    prerequisites: List[str]

@dataclass
class RecommendationResult:
    success: bool
    message: str
    career_title: str
    initial_skills: List[str]
    acquired_skills: List[str]
    missing_skills_before: List[str]
    missing_skills_after: List[str]
    learning_path: List[Course]
    path_steps: List[RecommendationStep]
    total_cost: float
    total_duration_hours: float
    nodes_expanded: int
    execution_time_ms: float

class AStarRecommender:
    """
    Genuine A* Search Engine implemented from scratch in Python.
    Uses f(n) = g(n) + h(n) where:
    - g(n) is the accumulated cost of completed courses (duration + difficulty penalty)
    - h(n) is an admissible heuristic estimating remaining cost to acquire missing career skills
    """
    def __init__(self, graph: CourseGraph):
        self.graph = graph
        self.heuristic_calc = HeuristicCalculator(graph.courses)

    def recommend(
        self,
        student_initial_skills: Set[str],
        career_id: str,
        student_interests: Optional[Set[str]] = None
    ) -> RecommendationResult:
        start_time = time.perf_counter()
        
        if student_interests is None:
            student_interests = set()

        career = self.graph.careers_dict.get(career_id)
        if not career:
            return RecommendationResult(
                success=False,
                message=f"Career goal '{career_id}' not found in database.",
                career_title="Unknown",
                initial_skills=list(student_initial_skills),
                acquired_skills=list(student_initial_skills),
                missing_skills_before=[],
                missing_skills_after=[],
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=0,
                execution_time_ms=(time.perf_counter() - start_time) * 1000.0
            )

        required_skills = set(career.required_skills)
        initial_skills = set(student_initial_skills)
        missing_skills_before = list(required_skills - initial_skills)

        # Initial State: no completed courses
        start_state = State(completed_courses=frozenset())
        initial_acquired = start_state.get_acquired_skills(initial_skills, self.graph.courses_dict)

        # Check if student already possesses all required skills (Goal state at start)
        if required_skills.issubset(initial_acquired):
            return RecommendationResult(
                success=True,
                message="Student already possesses all skills required for this career goal.",
                career_title=career.title,
                initial_skills=list(initial_skills),
                acquired_skills=list(initial_acquired),
                missing_skills_before=missing_skills_before,
                missing_skills_after=[],
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=0,
                execution_time_ms=(time.perf_counter() - start_time) * 1000.0
            )

        initial_h = self.heuristic_calc.calculate(start_state, initial_skills, required_skills, self.graph.courses_dict)
        if initial_h == float('inf'):
            return RecommendationResult(
                success=False,
                message="Goal unreachable: dataset does not contain courses teaching required skills.",
                career_title=career.title,
                initial_skills=list(initial_skills),
                acquired_skills=list(initial_acquired),
                missing_skills_before=missing_skills_before,
                missing_skills_after=missing_skills_before,
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=0,
                execution_time_ms=(time.perf_counter() - start_time) * 1000.0
            )

        # Priority Queue storing tuples: (f_score, tie_breaker, g_score, state, path_course_ids)
        # Tie breaker uses interest alignment (negative interest match count) to prefer interested courses on equal f
        counter = 0
        open_set = []
        heapq.heappush(open_set, (initial_h, 0, 0.0, counter, start_state, []))

        # Closed set storing lowest g_score achieved for each state
        g_scores: Dict[State, float] = {start_state: 0.0}
        nodes_expanded = 0

        final_path_ids: Optional[List[str]] = None
        final_g_score: float = 0.0

        while open_set:
            f, tie_breaker, g, _, current_state, path = heapq.heappop(open_set)
            nodes_expanded += 1

            # Skip if we already found a cheaper path to this state
            if g > g_scores.get(current_state, float('inf')):
                continue

            current_acquired = current_state.get_acquired_skills(initial_skills, self.graph.courses_dict)

            # Goal Test
            if required_skills.issubset(current_acquired):
                final_path_ids = path
                final_g_score = g
                break

            # Successor Function: Find courses whose prerequisites are satisfied
            for course in self.graph.courses:
                if course.id in current_state.completed_courses:
                    continue # Already completed

                # Check if all prerequisites are satisfied by acquired skills
                prereqs_met = all(p in current_acquired for p in course.prerequisites)
                if not prereqs_met:
                    continue

                # Check if course actually contributes to goal or missing prerequisites
                course_skills_set = set(course.skills)
                if not (course_skills_set - current_acquired):
                    continue

                step_cost = calculate_course_cost(course)
                tentative_g = g + step_cost
                next_completed = current_state.completed_courses | {course.id}
                next_state = State(next_completed)

                if tentative_g < g_scores.get(next_state, float('inf')):
                    g_scores[next_state] = tentative_g
                    h = self.heuristic_calc.calculate(next_state, initial_skills, required_skills, self.graph.courses_dict)
                    
                    if h != float('inf'):
                        next_f = tentative_g + h
                        interest_match = sum(1 for tag in course.interests if tag in student_interests)
                        counter += 1
                        heapq.heappush(open_set, (next_f, -interest_match, tentative_g, counter, next_state, path + [course.id]))


        execution_time_ms = (time.perf_counter() - start_time) * 1000.0

        if final_path_ids is None:
            return RecommendationResult(
                success=False,
                message="Goal unreachable: no valid sequence of courses can satisfy all career skill prerequisites.",
                career_title=career.title,
                initial_skills=list(initial_skills),
                acquired_skills=list(initial_acquired),
                missing_skills_before=missing_skills_before,
                missing_skills_after=missing_skills_before,
                learning_path=[],
                path_steps=[],
                total_cost=0.0,
                total_duration_hours=0.0,
                nodes_expanded=nodes_expanded,
                execution_time_ms=execution_time_ms
            )

        # Build detailed step breakdown
        learning_path = [self.graph.courses_dict[cid] for cid in final_path_ids]
        path_steps = []
        accumulated_g = 0.0
        total_duration = 0.0
        temp_state = State(completed_courses=frozenset())

        for cid in final_path_ids:
            c = self.graph.courses_dict[cid]
            c_cost = calculate_course_cost(c)
            accumulated_g += c_cost
            total_duration += c.duration_hours
            temp_state = State(temp_state.completed_courses | {cid})
            step_h = self.heuristic_calc.calculate(temp_state, initial_skills, required_skills, self.graph.courses_dict)
            
            difficulty_penalty = c_cost - c.duration_hours

            path_steps.append(RecommendationStep(
                course_id=c.id,
                course_name=c.name,
                duration_hours=c.duration_hours,
                difficulty=c.difficulty,
                difficulty_penalty=difficulty_penalty,
                step_cost=c_cost,
                accumulated_g=accumulated_g,
                heuristic_h=step_h,
                total_f=accumulated_g + step_h,
                skills_acquired=c.skills,
                prerequisites=c.prerequisites
            ))

        final_acquired = temp_state.get_acquired_skills(initial_skills, self.graph.courses_dict)
        missing_skills_after = list(required_skills - final_acquired)

        return RecommendationResult(
            success=True,
            message="Optimal learning path successfully generated using A* Search.",
            career_title=career.title,
            initial_skills=list(initial_skills),
            acquired_skills=list(final_acquired),
            missing_skills_before=missing_skills_before,
            missing_skills_after=missing_skills_after,
            learning_path=learning_path,
            path_steps=path_steps,
            total_cost=final_g_score,
            total_duration_hours=total_duration,
            nodes_expanded=nodes_expanded,
            execution_time_ms=execution_time_ms
        )
