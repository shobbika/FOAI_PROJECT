from typing import Any, Dict

DIFFICULTY_PENALTY: Dict[str, float] = {
    "Beginner": 0.0,
    "Intermediate": 5.0,
    "Advanced": 10.0
}

def calculate_course_cost(course: Any) -> float:
    """
    Calculates the cost of taking a course.
    Formula: course_cost = duration_hours + difficulty_penalty
    This cost function is strictly non-negative and explainable.
    """
    duration = float(getattr(course, "duration_hours", 0.0))
    difficulty = getattr(course, "difficulty", "Beginner")
    penalty = DIFFICULTY_PENALTY.get(difficulty, 0.0)
    
    cost = duration + penalty
    return max(0.0, cost)
