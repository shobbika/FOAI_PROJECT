from typing import List, Optional
from pydantic import BaseModel, Field

class CourseSchema(BaseModel):
    id: str
    name: str
    description: str
    category: str
    skills: List[str]
    prerequisites: List[str]
    difficulty: str
    duration_hours: float
    careers: List[str]
    interests: List[str]

class CareerSchema(BaseModel):
    id: str
    title: str
    description: str
    required_skills: List[str]

class RecommendationRequest(BaseModel):
    student_name: str = Field(default="Student", description="Name or nickname of student")
    current_skills: List[str] = Field(default_factory=list, description="Skills student already possesses")
    knowledge_level: str = Field(default="Beginner", description="Beginner, Intermediate, or Advanced")
    career_id: str = Field(..., description="Target career goal ID")
    interests: List[str] = Field(default_factory=list, description="Learning interest tags")
    available_hours_per_week: float = Field(default=10.0, ge=1.0, description="Available study hours per week")

class RecommendationStepSchema(BaseModel):
    course_id: str
    course_name: str
    duration_hours: float
    difficulty: str
    difficulty_penalty: float
    step_cost: float
    accumulated_g: float
    heuristic_h: float
    total_f: float
    skills_acquired: List[str]
    prerequisites: List[str]

class RecommendationResponse(BaseModel):
    success: bool
    message: str
    career_title: str
    initial_skills: List[str]
    acquired_skills: List[str]
    missing_skills_before: List[str]
    missing_skills_after: List[str]
    learning_path: List[CourseSchema]
    path_steps: List[RecommendationStepSchema]
    total_cost: float
    total_duration_hours: float
    estimated_weeks: float
    nodes_expanded: int
    execution_time_ms: float

class StudentProfileRequest(BaseModel):
    name: str = "Student"
    knowledge_level: str = "Beginner"
    available_hours_per_week: float = 10.0
    current_skills: List[str] = []
    interests: List[str] = []
    selected_career_id: str

class StudentProfileResponse(BaseModel):
    id: int
    name: str
    knowledge_level: str
    available_hours_per_week: float
    current_skills: List[str]
    interests: List[str]
    selected_career_id: str

class ProgressUpdateRequest(BaseModel):
    student_id: int
    completed_course_ids: List[str]

class ProgressResponse(BaseModel):
    student_id: int
    completed_course_ids: List[str]
    updated_at: str

class AlgorithmMetricSchema(BaseModel):
    algorithm_name: str
    success: bool
    path_length: int
    total_cost: float
    total_duration_hours: float
    nodes_expanded: int
    execution_time_ms: float
    course_ids: List[str]

class ComparisonResponse(BaseModel):
    career_id: str
    career_title: str
    initial_skills: List[str]
    astar_metrics: AlgorithmMetricSchema
    ucs_metrics: AlgorithmMetricSchema
    nodes_saved_by_astar: int
    percentage_node_reduction: float
    is_path_cost_identical: bool

class StudyTaskSchema(BaseModel):
    task_id: str
    course_id: str
    course_name: str
    topic: str
    task_type: str
    hours: float
    completed: bool = False

class DayScheduleSchema(BaseModel):
    day_number: int
    date: str
    day_of_week: str
    week_number: int
    daily_total_hours: float
    tasks: List[StudyTaskSchema]

class CourseScheduleSummarySchema(BaseModel):
    course_id: str
    course_name: str
    duration_hours: float
    difficulty: str
    difficulty_penalty: float
    skills_acquired: List[str]
    prerequisites: List[str]
    start_date: Optional[str] = None
    estimated_completion_date: Optional[str] = None
    total_tasks_count: int

class AlgorithmExplanationStepSchema(BaseModel):
    step_number: int
    course_id: str
    course_name: str
    difficulty: str
    duration_hours: float
    difficulty_penalty_points: float
    step_cost: float
    accumulated_g_cost: float
    estimated_remaining_h: float
    total_f_cost: float
    reason: str

class StudyPlanRequest(BaseModel):
    student_name: str = Field(default="Student", description="Name of student")
    student_email: Optional[str] = None
    current_skills: List[str] = Field(default_factory=list, description="Skills already acquired")
    career_id: str = Field(..., description="Target career goal ID")
    interests: List[str] = Field(default_factory=list)
    daily_study_hours: float = Field(default=2.0, ge=0.5, le=16.0, description="Available study hours per day")
    available_days: List[str] = Field(
        default_factory=lambda: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        description="Days available for study in a week"
    )
    start_date: Optional[str] = Field(default=None, description="Plan start date (YYYY-MM-DD)")

class StudyPlanResponse(BaseModel):
    success: bool
    message: str
    career_title: str
    initial_skills: List[str]
    total_planned_hours: float
    daily_study_hours: float
    weekly_study_hours: float
    available_days: List[str]
    start_date: str
    estimated_completion_date: str
    total_calendar_days: int
    total_study_days: int
    total_weeks: int
    courses_summary: List[CourseScheduleSummarySchema]
    schedule_days: List[DayScheduleSchema]
    algorithm_steps: List[AlgorithmExplanationStepSchema]
    cost_function_description: str
    heuristic_description: str
    why_path_chosen: str
    completed_task_ids: List[str] = Field(default_factory=list)

class StudyPlanProgressRequest(BaseModel):
    student_id: str = Field(..., description="Student email or identifier")
    completed_task_ids: List[str] = Field(default_factory=list)

class StudyPlanProgressResponse(BaseModel):
    student_id: str
    completed_task_ids: List[str]
    updated_at: str

