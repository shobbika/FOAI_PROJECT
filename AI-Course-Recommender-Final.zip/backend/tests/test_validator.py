import unittest
from app.recommender.graph import CourseGraph, DatasetValidationError

class TestDatasetValidator(unittest.TestCase):
    def setUp(self):
        self.valid_careers = [
            {
                "id": "car1",
                "title": "Role 1",
                "description": "Desc 1",
                "required_skills": ["Skill B"]
            }
        ]

    def test_duplicate_course_ids(self):
        courses = [
            {"id": "C1", "name": "Course 1", "description": "D", "category": "Cat", "skills": ["Skill A"], "prerequisites": [], "difficulty": "Beginner", "duration_hours": 10},
            {"id": "C1", "name": "Course 1 Dup", "description": "D", "category": "Cat", "skills": ["Skill B"], "prerequisites": [], "difficulty": "Beginner", "duration_hours": 10}
        ]
        with self.assertRaises(DatasetValidationError) as ctx:
            CourseGraph.validate_and_parse(courses, self.valid_careers)
        self.assertIn("Duplicate course ID", str(ctx.exception))

    def test_missing_required_field(self):
        courses = [
            {"id": "C1", "name": "Course 1", "description": "D", "category": "Cat", "skills": ["Skill A"], "prerequisites": [], "difficulty": "Beginner"} # missing duration_hours
        ]
        with self.assertRaises(DatasetValidationError) as ctx:
            CourseGraph.validate_and_parse(courses, self.valid_careers)
        self.assertIn("missing required field", str(ctx.exception).lower())

    def test_invalid_difficulty(self):
        courses = [
            {"id": "C1", "name": "Course 1", "description": "D", "category": "Cat", "skills": ["Skill A"], "prerequisites": [], "difficulty": "SuperHard", "duration_hours": 10}
        ]
        with self.assertRaises(DatasetValidationError) as ctx:
            CourseGraph.validate_and_parse(courses, self.valid_careers)
        self.assertIn("invalid difficulty", str(ctx.exception).lower())

    def test_cyclic_prerequisites_detection(self):
        # Course 1 teaches Skill A, requires Skill B
        # Course 2 teaches Skill B, requires Skill A
        courses = [
            {"id": "C1", "name": "Course 1", "description": "D", "category": "Cat", "skills": ["Skill A"], "prerequisites": ["Skill B"], "difficulty": "Beginner", "duration_hours": 10},
            {"id": "C2", "name": "Course 2", "description": "D", "category": "Cat", "skills": ["Skill B"], "prerequisites": ["Skill A"], "difficulty": "Beginner", "duration_hours": 10}
        ]
        parsed_courses, parsed_careers = CourseGraph.validate_and_parse(courses, self.valid_careers)
        graph = CourseGraph(parsed_courses, parsed_careers)
        with self.assertRaises(DatasetValidationError) as ctx:
            graph.validate_prerequisite_cycles()
        self.assertIn("Cyclic prerequisite dependency", str(ctx.exception))

if __name__ == "__main__":
    unittest.main()
