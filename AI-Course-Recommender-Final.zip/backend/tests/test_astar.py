import os
import unittest
from app.recommender.graph import CourseGraph, Course, CareerGoal, DatasetValidationError
from app.recommender.astar import AStarRecommender
from app.recommender.ucs import UCSRecommender
from app.recommender.cost import calculate_course_cost

class TestAStarRecommender(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Load dataset from JSON
        data_dir = os.path.join(os.path.dirname(__file__), "..", "app", "data")
        courses_json = os.path.abspath(os.path.join(data_dir, "courses.json"))
        careers_json = os.path.abspath(os.path.join(data_dir, "careers.json"))
        cls.graph = CourseGraph.load_from_json(courses_json, careers_json)
        cls.recommender = AStarRecommender(cls.graph)
        cls.ucs = UCSRecommender(cls.graph)

    def test_scenario_1_no_skills_to_ai_engineer(self):
        """Scenario 1: Student with no skills seeking to become an AI Engineer."""
        res = self.recommender.recommend(set(), "ai_engineer")
        self.assertTrue(res.success)
        self.assertGreater(len(res.learning_path), 0)
        
        # Verify required career skills are all acquired at end
        ai_career = self.graph.careers_dict["ai_engineer"]
        for req_skill in ai_career.required_skills:
            self.assertIn(req_skill, res.acquired_skills)

        # Verify prerequisite ordering
        acquired = set()
        for course in res.learning_path:
            for prereq in course.prerequisites:
                self.assertIn(prereq, acquired, f"Prerequisite '{prereq}' missing before course '{course.id}'")
            acquired.update(course.skills)

    def test_scenario_2_python_skill_to_ai_engineer(self):
        """Scenario 2: Student who already knows Python seeking to become an AI Engineer."""
        res_no_python = self.recommender.recommend(set(), "ai_engineer")
        res_with_python = self.recommender.recommend({"Python Programming"}, "ai_engineer")
        
        self.assertTrue(res_with_python.success)
        # CS101 (Intro to Python) should NOT be in the path if Python is already known
        path_course_ids = [c.id for c in res_with_python.learning_path]
        self.assertNotIn("CS101", path_course_ids)
        self.assertLess(res_with_python.total_cost, res_no_python.total_cost)

    def test_scenario_3_data_scientist_path(self):
        """Scenario 3: Student seeking to become a Data Scientist."""
        res = self.recommender.recommend(set(), "data_scientist")
        self.assertTrue(res.success)
        ds_career = self.graph.careers_dict["data_scientist"]
        for req in ds_career.required_skills:
            self.assertIn(req, res.acquired_skills)

    def test_scenario_4_software_developer_path(self):
        """Scenario 4: Student seeking to become a Software Developer."""
        res = self.recommender.recommend(set(), "software_developer")
        self.assertTrue(res.success)
        sd_career = self.graph.careers_dict["software_developer"]
        for req in sd_career.required_skills:
            self.assertIn(req, res.acquired_skills)

    def test_scenario_5_already_possesses_all_skills(self):
        """Scenario 5: Student who already has all required career skills."""
        ai_skills = set(self.graph.careers_dict["ai_engineer"].required_skills)
        res = self.recommender.recommend(ai_skills, "ai_engineer")
        self.assertTrue(res.success)
        self.assertEqual(len(res.learning_path), 0)
        self.assertEqual(res.total_cost, 0.0)

    def test_scenario_6_invalid_career_goal(self):
        """Scenario 6: An invalid career goal."""
        res = self.recommender.recommend(set(), "non_existent_career")
        self.assertFalse(res.success)
        self.assertIn("not found", res.message.lower())

    def test_scenario_7_unreachable_career_goal(self):
        """Scenario 7: An unreachable career goal."""
        unreachable_career = CareerGoal(
            id="impossible_role",
            title="Quantum Teleportation Specialist",
            description="Requires impossible skills not in catalog",
            required_skills=["Quantum Teleportation Magic"]
        )
        custom_graph = CourseGraph(self.graph.courses, [unreachable_career])
        custom_recommender = AStarRecommender(custom_graph)
        
        res = custom_recommender.recommend(set(), "impossible_role")
        self.assertFalse(res.success)
        self.assertIn("unreachable", res.message.lower())

    def test_scenario_8_multiple_prerequisites(self):
        """Scenario 8: Courses with multiple prerequisites are correctly handled."""
        # DATA301 requires both "Python Programming" AND "SQL & Database Design"
        res = self.recommender.recommend(set(), "data_scientist")
        self.assertTrue(res.success)
        
        path_ids = [c.id for c in res.learning_path]
        if "DATA301" in path_ids:
            data301_index = path_ids.index("DATA301")
            prior_courses = res.learning_path[:data301_index]
            prior_skills = set()
            for c in prior_courses:
                prior_skills.update(c.skills)
            self.assertIn("Python Programming", prior_skills)
            self.assertIn("SQL & Database Design", prior_skills)

    def test_scenario_9_cost_sum_equality(self):
        """Test that the total path cost equals the sum of step costs."""
        res = self.recommender.recommend(set(), "ai_engineer")
        self.assertTrue(res.success)
        
        summed_cost = sum(calculate_course_cost(c) for c in res.learning_path)
        self.assertAlmostEqual(res.total_cost, summed_cost)

    def test_scenario_10_alternative_courses(self):
        """Scenario 10: Case where two alternative courses can teach the same skill."""
        # ML301 (dur=40) and ML302 (dur=45) both teach "Machine Learning Fundamentals"
        res = self.recommender.recommend({"Python Programming", "Linear Algebra & Statistics"}, "ai_engineer")
        self.assertTrue(res.success)
        path_ids = [c.id for c in res.learning_path]
        
        # A* should select the cheaper alternative (ML301 over ML302)
        if "Machine Learning Fundamentals" in res.acquired_skills:
            self.assertIn("ML301", path_ids)
            self.assertNotIn("ML302", path_ids)

    def test_astar_vs_ucs_optimality_and_node_expansion(self):
        """Test that A* produces the same optimal path cost as UCS but expands <= nodes."""
        res_astar = self.recommender.recommend(set(), "ai_engineer")
        res_ucs = self.ucs.recommend(set(), "ai_engineer")
        
        self.assertTrue(res_astar.success)
        self.assertTrue(res_ucs.success)
        # Optimal cost should match
        self.assertAlmostEqual(res_astar.total_cost, res_ucs.total_cost)
        # A* heuristic should prune search space, resulting in fewer or equal node expansions
        self.assertLessEqual(res_astar.nodes_expanded, res_ucs.nodes_expanded)

if __name__ == "__main__":
    unittest.main()
