import os
import unittest
import datetime

from app.recommender.graph import CourseGraph, Course, CareerGoal
from app.recommender.planner import StudyPlanner
from app.database import engine, Base, SessionLocal
from app.models import StudyPlanProgressModel

class TestStudyPlanner(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        data_dir = os.path.join(os.path.dirname(__file__), "..", "app", "data")
        courses_json = os.path.abspath(os.path.join(data_dir, "courses.json"))
        careers_json = os.path.abspath(os.path.join(data_dir, "careers.json"))
        cls.graph = CourseGraph.load_from_json(courses_json, careers_json)
        cls.planner = StudyPlanner(cls.graph)
        Base.metadata.create_all(bind=engine)

    def test_daily_hour_limits_never_exceeded(self):
        """Verify that no day in the generated schedule exceeds the specified daily limit."""
        daily_limit = 2.0
        plan = self.planner.create_study_plan(
            student_initial_skills=set(),
            career_id="ai_engineer",
            daily_study_hours=daily_limit,
            available_days=["Monday", "Wednesday", "Friday"],
            start_date_str="2026-10-20"
        )
        self.assertTrue(plan.success)
        self.assertGreater(len(plan.schedule_days), 0)

        for day in plan.schedule_days:
            self.assertLessEqual(
                day.daily_total_hours,
                daily_limit + 1e-4,
                f"Day {day.date} exceeded daily limit: {day.daily_total_hours} > {daily_limit}"
            )
            # Verify sum of task hours on that day equals daily_total_hours
            task_sum = sum(t.hours for t in day.tasks)
            self.assertAlmostEqual(day.daily_total_hours, task_sum, places=2)

    def test_course_hour_totals_match_dataset_durations(self):
        """Verify that the scheduled task hours for each course exactly equal the dataset course duration."""
        plan = self.planner.create_study_plan(
            student_initial_skills=set(),
            career_id="software_developer",
            daily_study_hours=3.0,
            available_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            start_date_str="2026-10-20"
        )
        self.assertTrue(plan.success)

        # Map course_id -> sum of hours across all days
        scheduled_hours_by_course = {}
        for day in plan.schedule_days:
            for t in day.tasks:
                scheduled_hours_by_course[t.course_id] = (
                    scheduled_hours_by_course.get(t.course_id, 0.0) + t.hours
                )

        for summary in plan.courses_summary:
            c = self.graph.courses_dict[summary.course_id]
            actual_scheduled = scheduled_hours_by_course.get(c.id, 0.0)
            self.assertAlmostEqual(
                actual_scheduled,
                c.duration_hours,
                places=1,
                msg=f"Course {c.id} duration mismatch: scheduled {actual_scheduled} vs expected {c.duration_hours}"
            )

    def test_prerequisite_ordering_in_schedule(self):
        """Verify that prerequisite courses complete before any dependent course begins."""
        # For AI Engineer, DL401 requires ML301, ML301 requires Linear Algebra and Python
        plan = self.planner.create_study_plan(
            student_initial_skills=set(),
            career_id="ai_engineer",
            daily_study_hours=2.0,
            available_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            start_date_str="2026-10-20"
        )
        self.assertTrue(plan.success)

        course_first_day = {}
        course_last_day = {}

        for day in plan.schedule_days:
            for t in day.tasks:
                if t.course_id not in course_first_day:
                    course_first_day[t.course_id] = day.day_number
                course_last_day[t.course_id] = day.day_number

        # Check all courses in plan against their prerequisites
        for summary in plan.courses_summary:
            c = self.graph.courses_dict[summary.course_id]
            for prereq_skill in c.prerequisites:
                # Find which course in the plan taught this prerequisite
                prereq_course_ids = [
                    s.course_id for s in plan.courses_summary
                    if prereq_skill in self.graph.courses_dict[s.course_id].skills
                ]
                for p_id in prereq_course_ids:
                    if p_id != c.id and p_id in course_last_day:
                        self.assertLess(
                            course_last_day[p_id],
                            course_first_day[c.id],
                            f"Prerequisite course {p_id} finished on day {course_last_day[p_id]} but dependent course {c.id} started on day {course_first_day[c.id]}"
                        )

    def test_student_with_existing_skills_omits_unnecessary_courses(self):
        """Verify that a student who already knows Python does not have CS101 in the study plan."""
        plan = self.planner.create_study_plan(
            student_initial_skills={"Python Programming"},
            career_id="ai_engineer",
            daily_study_hours=2.0,
            available_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
            start_date_str="2026-10-20"
        )
        self.assertTrue(plan.success)

        scheduled_courses = {s.course_id for s in plan.courses_summary}
        self.assertNotIn("CS101", scheduled_courses, "CS101 should be skipped because Python is already acquired!")

    def test_all_skills_already_acquired(self):
        """Verify that if student already has all career skills, plan handles it gracefully with 0 planned hours."""
        ai_skills = set(self.graph.careers_dict["ai_engineer"].required_skills)
        plan = self.planner.create_study_plan(
            student_initial_skills=ai_skills,
            career_id="ai_engineer",
            daily_study_hours=2.0
        )
        self.assertTrue(plan.success)
        self.assertEqual(plan.total_planned_hours, 0.0)
        self.assertEqual(len(plan.schedule_days), 0)

    def test_unreachable_career_goal_handling(self):
        """Verify that an unreachable career goal returns a clear explanation and fails safely."""
        unreachable_career = CareerGoal(
            id="impossible_goal",
            title="Teleportation Engineer",
            description="Requires impossible skills",
            required_skills=["Subatomic Teleportation"]
        )
        custom_graph = CourseGraph(self.graph.courses, [unreachable_career])
        custom_planner = StudyPlanner(custom_graph)

        plan = custom_planner.create_study_plan(
            student_initial_skills=set(),
            career_id="impossible_goal",
            daily_study_hours=2.0
        )
        self.assertFalse(plan.success)
        self.assertIn("unreachable", plan.message.lower())

    def test_invalid_study_schedules(self):
        """Verify that invalid daily study hours or empty available days raise clear ValueErrors."""
        # 0 hours per day
        with self.assertRaises(ValueError) as ctx:
            self.planner.create_study_plan(set(), "ai_engineer", daily_study_hours=0.0)
        self.assertIn("greater than 0", str(ctx.exception))

        # Negative hours
        with self.assertRaises(ValueError) as ctx:
            self.planner.create_study_plan(set(), "ai_engineer", daily_study_hours=-2.0)
        self.assertIn("greater than 0", str(ctx.exception))

        # Empty days
        with self.assertRaises(ValueError) as ctx:
            self.planner.create_study_plan(set(), "ai_engineer", daily_study_hours=2.0, available_days=[])
        self.assertIn("available study day", str(ctx.exception))

        # Invalid day names
        with self.assertRaises(ValueError) as ctx:
            self.planner.create_study_plan(set(), "ai_engineer", daily_study_hours=2.0, available_days=["InvalidDay"])
        self.assertIn("available study day", str(ctx.exception))

    def test_algorithm_explanation_values_match_astar(self):
        """Verify that g(n), h(n), f(n), and difficulty penalty match A* calculations."""
        plan = self.planner.create_study_plan(
            student_initial_skills=set(),
            career_id="data_scientist",
            daily_study_hours=2.0,
            available_days=["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        )
        self.assertTrue(plan.success)
        self.assertGreater(len(plan.algorithm_steps), 0)

        accumulated_cost = 0.0
        for step in plan.algorithm_steps:
            c = self.graph.courses_dict[step.course_id]
            expected_penalty = step.difficulty_penalty_points
            expected_step_cost = c.duration_hours + expected_penalty
            accumulated_cost += expected_step_cost

            self.assertAlmostEqual(step.step_cost, expected_step_cost)
            self.assertAlmostEqual(step.accumulated_g_cost, accumulated_cost)
            self.assertAlmostEqual(step.total_f_cost, step.accumulated_g_cost + step.estimated_remaining_h)

    def test_completed_tasks_persistence(self):
        """Verify SQLite database persistence for completed study plan tasks."""
        db = SessionLocal()
        test_student_id = "test_student_123@university.edu"
        task_ids = ["task-CS101-1", "task-CS101-2", "task-CS104-1"]

        # Clean existing
        db.query(StudyPlanProgressModel).filter(StudyPlanProgressModel.student_id == test_student_id).delete()
        db.commit()

        # Save progress
        import json
        record = StudyPlanProgressModel(
            student_id=test_student_id,
            completed_task_ids_json=json.dumps(task_ids)
        )
        db.add(record)
        db.commit()

        # Fetch
        saved = db.query(StudyPlanProgressModel).filter(StudyPlanProgressModel.student_id == test_student_id).first()
        self.assertIsNotNone(saved)
        loaded_tasks = json.loads(saved.completed_task_ids_json)
        self.assertEqual(loaded_tasks, task_ids)

        db.close()

if __name__ == "__main__":
    unittest.main()
