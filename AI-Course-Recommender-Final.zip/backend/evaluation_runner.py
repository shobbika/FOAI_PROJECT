import os
import sys

# Ensure backend directory is in python path
backend_dir = os.path.dirname(os.path.abspath(__file__))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app.recommender.graph import CourseGraph
from app.recommender.astar import AStarRecommender
from app.recommender.ucs import UCSRecommender

def run_academic_evaluation():
    data_dir = os.path.join(backend_dir, "app", "data")
    courses_json = os.path.join(data_dir, "courses.json")
    careers_json = os.path.join(data_dir, "careers.json")

    graph = CourseGraph.load_from_json(courses_json, careers_json)
    astar = AStarRecommender(graph)
    ucs = UCSRecommender(graph)

    print("=" * 80)
    print("ACADEMIC EVALUATION: A* SEARCH VS UNIFORM COST SEARCH (UCS / DIJKSTRA)")
    print("=" * 80)
    print(f"Total Knowledge Base Courses: {len(graph.courses)}")
    print(f"Total Target Careers: {len(graph.careers)}\n")

    header = f"{'Career Goal':<25} | {'Algo':<7} | {'Cost':<7} | {'Hours':<6} | {'Nodes Exp.':<10} | {'Time (ms)':<9} | {'Optimal?'}"
    print(header)
    print("-" * 80)

    test_scenarios = [
        ("AI Engineer (No Skills)", set(), "ai_engineer"),
        ("AI Engineer (Python Known)", {"Python Programming"}, "ai_engineer"),
        ("Data Scientist (No Skills)", set(), "data_scientist"),
        ("Software Developer (No Skills)", set(), "software_developer"),
        ("Full-Stack Web Dev (No Skills)", set(), "web_developer"),
        ("Cybersecurity (No Skills)", set(), "cybersecurity_specialist")
    ]

    for label, initial_skills, career_id in test_scenarios:
        res_a = astar.recommend(initial_skills, career_id)
        res_u = ucs.recommend(initial_skills, career_id)

        is_optimal = abs(res_a.total_cost - res_u.total_cost) < 1e-4

        print(f"{label:<25} | {'A*':<7} | {res_a.total_cost:<7.1f} | {res_a.total_duration_hours:<6.0f} | {res_a.nodes_expanded:<10} | {res_a.execution_time_ms:<9.2f} | {'Yes' if is_optimal else 'No'}")
        print(f"{'':<25} | {'UCS':<7} | {res_u.total_cost:<7.1f} | {res_u.total_duration_hours:<6.0f} | {res_u.nodes_expanded:<10} | {res_u.execution_time_ms:<9.2f} | {'Yes' if is_optimal else 'No'}")
        
        saved_nodes = res_u.nodes_expanded - res_a.nodes_expanded
        pct_saved = (saved_nodes / max(1, res_u.nodes_expanded)) * 100.0
        print(f"--> Result: A* saved {saved_nodes} node expansions ({pct_saved:.1f}% reduction in search space)\n")

if __name__ == "__main__":
    run_academic_evaluation()
